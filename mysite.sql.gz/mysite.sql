-- MySQL dump 10.13  Distrib 8.0.33, for Linux (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.33-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_eobchmcagdmkklpdvuvaqbcxiuufybxhtndx` (`primaryOwnerId`),
  CONSTRAINT `fk_dgsndpdrcasdcauiyccprvoggucgkmhrttee` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eobchmcagdmkklpdvuvaqbcxiuufybxhtndx` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fdscmnqnjwigqoejstdwqrmkubsbcdawvvtw` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_hyvgubdzvcmdjykypunecmnctjlvrkcowkgn` (`dateRead`),
  KEY `fk_fgryojptrnslhztjnhsptgubuubmihmnzhqp` (`pluginId`),
  CONSTRAINT `fk_fgryojptrnslhztjnhsptgubuubmihmnzhqp` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xecbltfkzozvcblkzitdagbbknvxwpjnnuvs` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sdhtzkcgqsenpdebjycwoqssnzxkoqyosyev` (`sessionId`,`volumeId`),
  KEY `idx_qgncpqbndwdhhziotfqjzdxccchxmxifygkt` (`volumeId`),
  CONSTRAINT `fk_gtgfnhltwhuefcphcoosbhctsojxuzebhiyt` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jiezdaeplmhityihrjlqporookefukrylalh` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fqvfpvqjyuzdjafktyelykqasivkkrrpvfxc` (`filename`,`folderId`),
  KEY `idx_lbgpnywgclkmvzrzuyojkiwrpxsxcdjxqhym` (`folderId`),
  KEY `idx_akqmraqnjqdhpskiospdubclaeisqgbacpuq` (`volumeId`),
  KEY `fk_wazaoqlxwzqdyrcrvxofmlklcrahtuqyqbqy` (`uploaderId`),
  CONSTRAINT `fk_juhgdwalsyibqtuavvlidxwtewmdjokqekgr` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wazaoqlxwzqdyrcrvxofmlklcrahtuqyqbqy` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xzbgvizfswgjijjwtyxnnyyxksnbpzvnruiu` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zancuqaxgaorweitxuplxqtanimxkffnkqkm` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES (18,1,1,1,'pods_case_4.png','image',NULL,1024,1024,1030440,NULL,0,0,'2024-04-29 10:59:16','2024-04-29 10:58:42','2024-04-29 10:59:16'),(19,1,1,1,'pods_case_3.png','image',NULL,1024,1024,1230910,NULL,0,0,'2024-04-29 10:59:16','2024-04-29 10:58:42','2024-04-29 10:59:16'),(20,1,1,1,'pods_case_2.png','image',NULL,1024,1024,1165446,NULL,0,0,'2024-04-29 10:59:17','2024-04-29 10:58:42','2024-04-29 10:59:17'),(21,1,1,1,'pods_case_1.png','image',NULL,1024,1024,1151864,NULL,0,0,'2024-04-29 10:59:17','2024-04-29 10:58:43','2024-04-29 10:59:17'),(22,1,1,1,'pods_9.png','image',NULL,1024,1024,1074436,NULL,0,0,'2024-04-29 10:59:17','2024-04-29 10:58:43','2024-04-29 10:59:17'),(23,1,1,1,'pods_8.png','image',NULL,1024,1024,843702,NULL,0,0,'2024-04-29 10:59:18','2024-04-29 10:58:43','2024-04-29 10:59:18'),(24,1,1,1,'pods_7.png','image',NULL,1024,1024,1056091,NULL,0,0,'2024-04-29 10:59:18','2024-04-29 10:58:43','2024-04-29 10:59:18'),(25,1,1,1,'pods_6.png','image',NULL,1024,1024,1277563,NULL,0,0,'2024-04-29 10:59:18','2024-04-29 10:58:44','2024-04-29 10:59:18'),(26,1,1,1,'pods_5.png','image',NULL,1024,1024,1169377,NULL,0,0,'2024-04-29 10:59:18','2024-04-29 10:58:44','2024-04-29 10:59:18'),(27,1,1,1,'pods_4.png','image',NULL,1024,1024,1065272,NULL,0,0,'2024-04-29 10:59:19','2024-04-29 10:58:44','2024-04-29 10:59:19'),(28,1,1,1,'pods_3.png','image',NULL,1024,1024,1097468,NULL,0,0,'2024-04-29 10:59:19','2024-04-29 10:58:45','2024-04-29 10:59:19'),(29,1,1,1,'pods_2.png','image',NULL,1024,1024,1042506,NULL,0,0,'2024-04-29 10:59:19','2024-04-29 10:58:45','2024-04-29 10:59:19'),(30,1,1,1,'pods_1.png','image',NULL,1024,1024,1122576,NULL,0,0,'2024-04-29 10:59:20','2024-04-29 10:58:45','2024-04-29 10:59:20'),(31,1,1,1,'bg_2.png','image',NULL,1456,816,789893,NULL,0,0,'2024-04-29 10:59:20','2024-04-29 10:58:46','2024-04-29 10:59:20'),(32,1,1,1,'bg_1.png','image',NULL,1456,816,875820,NULL,0,0,'2024-04-29 10:59:20','2024-04-29 10:58:46','2024-04-29 10:59:20'),(33,1,1,1,'aurowatch_1.png','image',NULL,1024,1024,933116,NULL,0,0,'2024-04-29 10:59:21','2024-04-29 10:58:46','2024-04-29 10:59:21'),(34,1,1,1,'aurovision_3.png','image',NULL,1024,1024,1018001,NULL,0,0,'2024-04-29 10:59:21','2024-04-29 10:58:47','2024-04-29 10:59:21'),(35,1,1,1,'aurovision_2.png','image',NULL,1024,1024,591789,NULL,0,0,'2024-04-29 10:59:21','2024-04-29 10:58:47','2024-04-29 10:59:21'),(36,1,1,1,'aurovision_1.png','image',NULL,2878,1362,1373737,NULL,0,0,'2024-04-29 10:59:22','2024-04-29 10:58:48','2024-04-29 10:59:22'),(37,1,1,1,'aurotouch_1.png','image',NULL,1024,1024,1430636,NULL,0,0,'2024-04-29 10:59:23','2024-04-29 10:58:49','2024-04-29 10:59:23'),(38,1,1,1,'aurotags_1.png','image',NULL,566,562,318355,NULL,0,0,'2024-04-29 10:59:23','2024-04-29 10:58:49','2024-04-29 10:59:23'),(39,1,1,1,'auroport_1.png','image',NULL,554,552,411710,NULL,0,0,'2024-04-29 10:59:23','2024-04-29 10:58:49','2024-04-29 10:59:23'),(40,1,1,1,'aurolink_4.png','image',NULL,1024,1024,961577,NULL,0,0,'2024-04-29 10:59:23','2024-04-29 10:58:50','2024-04-29 10:59:23'),(41,1,1,1,'aurolink_3.png','image',NULL,1024,1024,775039,NULL,0,0,'2024-04-29 10:59:24','2024-04-29 10:58:50','2024-04-29 10:59:24'),(42,1,1,1,'aurolink_2.png','image',NULL,1024,1024,836861,NULL,0,0,'2024-04-29 10:59:24','2024-04-29 10:58:51','2024-04-29 10:59:24'),(43,1,1,1,'aurolink_1.png','image',NULL,1024,1024,1016853,NULL,0,0,'2024-04-29 10:59:25','2024-04-29 10:58:51','2024-04-29 10:59:25'),(44,1,1,1,'pods_case_4_2024-04-29-105853_xkab.png','image',NULL,1024,1024,1030440,NULL,0,0,'2024-04-29 10:58:53','2024-04-29 10:58:53','2024-04-29 10:58:53'),(45,1,1,1,'pods_case_3_2024-04-29-105853_slrz.png','image',NULL,1024,1024,1230910,NULL,0,0,'2024-04-29 10:58:54','2024-04-29 10:58:54','2024-04-29 10:58:54'),(46,1,1,1,'pods_case_2_2024-04-29-105854_iafq.png','image',NULL,1024,1024,1165446,NULL,0,0,'2024-04-29 10:58:54','2024-04-29 10:58:54','2024-04-29 10:58:54'),(47,1,1,1,'pods_case_1_2024-04-29-105854_fipp.png','image',NULL,1024,1024,1151864,NULL,0,0,'2024-04-29 10:58:54','2024-04-29 10:58:54','2024-04-29 10:58:54'),(48,1,1,1,'pods_9_2024-04-29-105854_yyxa.png','image',NULL,1024,1024,1074436,NULL,0,0,'2024-04-29 10:58:55','2024-04-29 10:58:55','2024-04-29 10:58:55'),(49,1,1,1,'pods_8_2024-04-29-105855_yjyr.png','image',NULL,1024,1024,843702,NULL,0,0,'2024-04-29 10:58:55','2024-04-29 10:58:55','2024-04-29 10:58:55'),(50,1,1,1,'pods_7_2024-04-29-105855_xwhs.png','image',NULL,1024,1024,1056091,NULL,0,0,'2024-04-29 10:58:55','2024-04-29 10:58:55','2024-04-29 10:58:55'),(51,1,1,1,'pods_6_2024-04-29-105855_smwn.png','image',NULL,1024,1024,1277563,NULL,0,0,'2024-04-29 10:58:55','2024-04-29 10:58:56','2024-04-29 10:58:56'),(52,1,1,1,'pods_5_2024-04-29-105856_lpie.png','image',NULL,1024,1024,1169377,NULL,0,0,'2024-04-29 10:58:56','2024-04-29 10:58:56','2024-04-29 10:58:56'),(53,1,1,1,'pods_4_2024-04-29-105856_vhhp.png','image',NULL,1024,1024,1065272,NULL,0,0,'2024-04-29 10:58:56','2024-04-29 10:58:56','2024-04-29 10:58:56'),(54,1,1,1,'pods_3_2024-04-29-105856_spkn.png','image',NULL,1024,1024,1097468,NULL,0,0,'2024-04-29 10:58:56','2024-04-29 10:58:56','2024-04-29 10:58:56'),(55,1,1,1,'pods_2_2024-04-29-105856_wuvw.png','image',NULL,1024,1024,1042506,NULL,0,0,'2024-04-29 10:58:57','2024-04-29 10:58:57','2024-04-29 10:58:57'),(56,1,1,1,'pods_1_2024-04-29-105857_uzis.png','image',NULL,1024,1024,1122576,NULL,0,0,'2024-04-29 10:58:57','2024-04-29 10:58:57','2024-04-29 10:58:57'),(57,1,1,1,'bg_2_2024-04-29-105857_bhqn.png','image',NULL,1456,816,789893,NULL,0,0,'2024-04-29 10:58:57','2024-04-29 10:58:57','2024-04-29 10:58:57'),(58,1,1,1,'bg_1_2024-04-29-105857_zfwq.png','image',NULL,1456,816,875820,NULL,0,0,'2024-04-29 10:58:58','2024-04-29 10:58:58','2024-04-29 10:58:58'),(59,1,1,1,'aurowatch_1_2024-04-29-105858_unjr.png','image',NULL,1024,1024,933116,NULL,0,0,'2024-04-29 10:58:58','2024-04-29 10:58:58','2024-04-29 10:58:58'),(60,1,1,1,'aurovision_3_2024-04-29-105858_whml.png','image',NULL,1024,1024,924443,NULL,0,0,'2024-04-29 10:58:58','2024-04-29 10:58:58','2024-04-29 10:58:58'),(61,1,1,1,'aurovision_2_2024-04-29-105859_beum.png','image',NULL,1024,1024,591789,NULL,0,0,'2024-04-29 10:58:59','2024-04-29 10:58:59','2024-04-29 10:58:59'),(62,1,1,1,'aurovision_1_2024-04-29-105859_lwrl.png','image',NULL,2878,1362,1373737,NULL,0,0,'2024-04-29 10:59:00','2024-04-29 10:59:00','2024-04-29 10:59:00'),(63,1,1,1,'aurotouch_1_2024-04-29-105900_kohl.png','image',NULL,1024,1024,1430636,NULL,0,0,'2024-04-29 10:59:00','2024-04-29 10:59:00','2024-04-29 10:59:00'),(64,1,1,1,'aurotags_1_2024-04-29-105900_nmgn.png','image',NULL,566,562,318355,NULL,0,0,'2024-04-29 10:59:01','2024-04-29 10:59:01','2024-04-29 10:59:01'),(65,1,1,1,'auroport_1_2024-04-29-105901_utrt.png','image',NULL,554,552,411710,NULL,0,0,'2024-04-29 10:59:01','2024-04-29 10:59:01','2024-04-29 10:59:01'),(66,1,1,1,'aurolink_4_2024-04-29-105901_qudu.png','image',NULL,1024,1024,961577,NULL,0,0,'2024-04-29 10:59:01','2024-04-29 10:59:01','2024-04-29 10:59:01'),(67,1,1,1,'aurolink_3_2024-04-29-105901_rtgz.png','image',NULL,1024,1024,775039,NULL,0,0,'2024-04-29 10:59:02','2024-04-29 10:59:02','2024-04-29 10:59:02'),(68,1,1,1,'aurolink_2_2024-04-29-105902_oxeu.png','image',NULL,1024,1024,836861,NULL,0,0,'2024-04-29 10:59:02','2024-04-29 10:59:02','2024-04-29 10:59:02'),(69,1,1,1,'aurolink_1_2024-04-29-105902_qzul.png','image',NULL,1024,1024,1016853,NULL,0,0,'2024-04-29 10:59:02','2024-04-29 10:59:02','2024-04-29 10:59:02'),(83,1,1,1,'pods_6.png','image',NULL,1024,1024,1277563,NULL,NULL,NULL,'2024-04-29 13:11:33','2024-04-29 13:11:33','2024-04-29 13:11:33'),(84,1,1,1,'pods_case_4.png','image',NULL,1024,1024,1030440,NULL,NULL,NULL,'2024-04-29 13:11:33','2024-04-29 13:11:33','2024-04-29 13:11:33'),(85,1,1,1,'pods_case_3.png','image',NULL,1024,1024,1230910,NULL,NULL,NULL,'2024-04-29 13:11:34','2024-04-29 13:11:34','2024-04-29 13:11:34'),(86,1,1,1,'pods_case_2.png','image',NULL,1024,1024,1165446,NULL,NULL,NULL,'2024-04-29 13:11:34','2024-04-29 13:11:34','2024-04-29 13:11:34'),(87,1,1,1,'pods_case_1.png','image',NULL,1024,1024,1151864,NULL,NULL,NULL,'2024-04-29 13:11:34','2024-04-29 13:11:34','2024-04-29 13:11:34'),(88,1,1,1,'pods_9.png','image',NULL,1024,1024,1074436,NULL,NULL,NULL,'2024-04-29 13:11:35','2024-04-29 13:11:35','2024-04-29 13:11:35'),(89,1,1,1,'pods_8.png','image',NULL,1024,1024,843702,NULL,NULL,NULL,'2024-04-29 13:11:35','2024-04-29 13:11:35','2024-04-29 13:11:35'),(90,1,1,1,'pods_7.png','image',NULL,1024,1024,1056091,NULL,NULL,NULL,'2024-04-29 13:11:35','2024-04-29 13:11:35','2024-04-29 13:11:35'),(91,1,1,1,'pods_5.png','image',NULL,1024,1024,1169377,NULL,NULL,NULL,'2024-04-29 13:11:35','2024-04-29 13:11:35','2024-04-29 13:11:35'),(92,1,1,1,'pods_4.png','image',NULL,1024,1024,1065272,NULL,NULL,NULL,'2024-04-29 13:11:36','2024-04-29 13:11:36','2024-04-29 13:11:36'),(93,1,1,1,'pods_3.png','image',NULL,1024,1024,1097468,NULL,NULL,NULL,'2024-04-29 13:11:36','2024-04-29 13:11:36','2024-04-29 13:11:36'),(94,1,1,1,'pods_2.png','image',NULL,1024,1024,1042506,NULL,NULL,NULL,'2024-04-29 13:11:36','2024-04-29 13:11:36','2024-04-29 13:11:36'),(95,1,1,1,'pods_1.png','image',NULL,1024,1024,1122576,NULL,NULL,NULL,'2024-04-29 13:11:37','2024-04-29 13:11:37','2024-04-29 13:11:37'),(96,1,1,1,'bg_2.png','image',NULL,1456,816,789893,NULL,NULL,NULL,'2024-04-29 13:11:37','2024-04-29 13:11:37','2024-04-29 13:11:37'),(97,1,1,1,'bg_1.png','image',NULL,1456,816,875820,NULL,NULL,NULL,'2024-04-29 13:11:37','2024-04-29 13:11:37','2024-04-29 13:11:37'),(98,1,1,1,'aurowatch_1.png','image',NULL,1024,1024,933116,NULL,NULL,NULL,'2024-04-29 13:11:38','2024-04-29 13:11:38','2024-04-29 13:11:38'),(99,1,1,1,'aurovision_3.png','image',NULL,1024,1024,924443,NULL,NULL,NULL,'2024-04-29 13:11:38','2024-04-29 13:11:38','2024-04-29 13:11:38'),(100,1,1,1,'aurovision_2.png','image',NULL,1024,1024,591789,NULL,NULL,NULL,'2024-04-29 13:11:38','2024-04-29 13:11:38','2024-04-29 13:11:38'),(101,1,1,1,'aurovision_1.png','image',NULL,2878,1362,1373737,NULL,NULL,NULL,'2024-04-29 13:11:39','2024-04-29 13:11:40','2024-04-29 13:11:40'),(102,1,1,1,'aurotouch_1.png','image',NULL,1024,1024,1430636,NULL,NULL,NULL,'2024-04-29 13:11:40','2024-04-29 13:11:40','2024-04-29 13:11:40'),(103,1,1,1,'aurotags_1.png','image',NULL,566,562,318355,NULL,NULL,NULL,'2024-04-29 13:11:40','2024-04-29 13:11:40','2024-04-29 13:11:40'),(104,1,1,1,'auroport_1.png','image',NULL,554,552,411710,NULL,NULL,NULL,'2024-04-29 13:11:40','2024-04-29 13:11:41','2024-04-29 13:11:41'),(105,1,1,1,'aurolink_4.png','image',NULL,1024,1024,961577,NULL,NULL,NULL,'2024-04-29 13:11:41','2024-04-29 13:11:41','2024-04-29 13:11:41'),(106,1,1,1,'aurolink_3.png','image',NULL,1024,1024,775039,NULL,NULL,NULL,'2024-04-29 13:11:41','2024-04-29 13:11:41','2024-04-29 13:11:41'),(107,1,1,1,'aurolink_2.png','image',NULL,1024,1024,836861,NULL,NULL,NULL,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:42'),(108,1,1,1,'aurolink_1.png','image',NULL,1024,1024,1016853,NULL,NULL,NULL,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:42'),(109,1,1,1,'auro_vid1.mp4','video',NULL,NULL,NULL,918543,NULL,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:42'),(124,1,1,1,'auro_vid1.mp4','video',NULL,NULL,NULL,918543,NULL,NULL,NULL,'2024-05-01 11:52:45','2024-05-01 11:52:45','2024-05-01 11:52:45');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_plbpsfhkqjtucpuudxufnuhpsaxumryusyaq` (`siteId`),
  CONSTRAINT `fk_jwwcmfeubpanipqrabatogwfsguiranhlbaw` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_plbpsfhkqjtucpuudxufnuhpsaxumryusyaq` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
INSERT INTO `assets_sites` VALUES (18,1,NULL),(19,1,NULL),(20,1,NULL),(21,1,NULL),(22,1,NULL),(23,1,NULL),(24,1,NULL),(25,1,NULL),(26,1,NULL),(27,1,NULL),(28,1,NULL),(29,1,NULL),(30,1,NULL),(31,1,NULL),(32,1,NULL),(33,1,NULL),(34,1,NULL),(35,1,NULL),(36,1,NULL),(37,1,NULL),(38,1,NULL),(39,1,NULL),(40,1,NULL),(41,1,NULL),(42,1,NULL),(43,1,NULL),(44,1,NULL),(45,1,NULL),(46,1,NULL),(47,1,NULL),(48,1,NULL),(49,1,NULL),(50,1,NULL),(51,1,NULL),(52,1,NULL),(53,1,NULL),(54,1,NULL),(55,1,NULL),(56,1,NULL),(57,1,NULL),(58,1,NULL),(59,1,NULL),(60,1,NULL),(61,1,NULL),(62,1,NULL),(63,1,NULL),(64,1,NULL),(65,1,NULL),(66,1,NULL),(67,1,NULL),(68,1,NULL),(69,1,NULL),(83,1,NULL),(84,1,NULL),(85,1,NULL),(86,1,NULL),(87,1,NULL),(88,1,NULL),(89,1,NULL),(90,1,NULL),(91,1,NULL),(92,1,NULL),(93,1,NULL),(94,1,NULL),(95,1,NULL),(96,1,NULL),(97,1,NULL),(98,1,NULL),(99,1,NULL),(100,1,NULL),(101,1,NULL),(102,1,NULL),(103,1,NULL),(104,1,NULL),(105,1,NULL),(106,1,NULL),(107,1,NULL),(108,1,NULL),(109,1,NULL),(124,1,NULL);
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_lpvovqqnkkfmrnryhcagggitonlsxvqrpgew` (`userId`),
  CONSTRAINT `fk_lpvovqqnkkfmrnryhcagggitonlsxvqrpgew` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qsbqrdsalwqzonkztzprezzbowotykrxzyop` (`groupId`),
  KEY `fk_vibvwlstnosfdxssccctaztrllaoutqxpftz` (`parentId`),
  CONSTRAINT `fk_cwwiigazpnbgdfiqfkfcjovwkktusknswlsj` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lsqvqbfpnyqhuglmtcfpnksqefmitlyzmgty` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vibvwlstnosfdxssccctaztrllaoutqxpftz` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vpblwgsilfisjiqkjuojfvmbstuttlazpvxu` (`name`),
  KEY `idx_voqskywmfootjnwyxgpeikfymkxkjnaxyvxs` (`handle`),
  KEY `idx_msmpcwbnketcoiftsnqtumufwguyhvkaqfmg` (`structureId`),
  KEY `idx_dhpkhwbgyymwcswkoblfbxsucracakxlrgyw` (`fieldLayoutId`),
  KEY `idx_fppdpppeybkhbfvuuyvarpxrcofwqfsnsphr` (`dateDeleted`),
  CONSTRAINT `fk_vvmbfmmasuqefaxvvggkmcwuglvpajutzktd` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ykanlhjlbpdxaopkzommqraesdzevuhuhsbs` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hwrolwrprhsmgzkvvetgtvafwexnrldwarbo` (`groupId`,`siteId`),
  KEY `idx_ogtcdxealfqpackdwbllnwmmazowuplashxy` (`siteId`),
  CONSTRAINT `fk_fypgrokhxupijdhzbantoumpkuqkexlwhrcr` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wrxuofvihdpluuoilooklixjlonxkhyfntjc` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_govuexnycjdnnxgyyqxasjkoudktsbjzpzhk` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_fuqqgwandyrbynaqnucfzalhezspkwynupgx` (`siteId`),
  KEY `fk_vsajgzqyqyzqsqqwsqixodqwhdytxshjekii` (`userId`),
  CONSTRAINT `fk_birosakcrskevgzjottrztcqpvyoycpkmwfv` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_fuqqgwandyrbynaqnucfzalhezspkwynupgx` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_vsajgzqyqyzqsqqwsqixodqwhdytxshjekii` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES (6,1,'title','2024-04-29 12:42:41',0,1),(12,1,'title','2024-04-29 10:50:55',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_qnleiceipffksgqiotowthrkgnkmklkglnog` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_jbxlwysekitetaaevsygeyhjlzdqlyjcbykw` (`siteId`),
  KEY `fk_uymjkiedxrsevaxzsejlvjhcybkpahhrboqe` (`fieldId`),
  KEY `fk_qziwwdvslmoiwzhqylqbhhvygxzzazzscgxk` (`userId`),
  CONSTRAINT `fk_jbxlwysekitetaaevsygeyhjlzdqlyjcbykw` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_jkkmgefkvuatupoebksgafhsyzbnvxkvenvt` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qziwwdvslmoiwzhqylqbhhvygxzzazzscgxk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_uymjkiedxrsevaxzsejlvjhcybkpahhrboqe` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES (6,1,1,'0048490d-ab9d-44b3-bb8e-3dcbbb2c429f','2024-05-01 10:44:37',0,1),(6,1,2,'822a27b1-5720-4c5a-9848-1e1602fd2cca','2024-05-01 10:52:14',0,1),(6,1,3,'c30b3ed4-6038-4639-b9b3-c7de78543e56','2024-04-29 12:54:38',0,1),(6,1,4,'17b30490-3b87-4158-a261-8e528b82c667','2024-05-01 10:52:14',0,1),(6,1,5,'0cb30b4a-3841-418c-8856-ea680bb04022','2024-05-01 01:05:24',0,1),(6,1,5,'22739534-4086-4c5f-80b4-8dffad3c0937','2024-05-01 10:52:14',0,1),(6,1,5,'72d7ee56-dc44-4879-a506-665a7d450161','2024-05-01 01:05:24',0,1),(6,1,6,'6f12157a-e134-4f12-b768-97a5ed2eeed6','2024-04-29 13:18:34',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_fpzlgfcftkalhoklpjtxmelokdkpvxrqfqht` (`userId`),
  CONSTRAINT `fk_fpzlgfcftkalhoklpjtxmelokdkpvxrqfqht` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fgqnwkqbaxqiajmlvulvpoaoohkdcdbbhcdu` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_xexuilgnpgufnrghtgnzkaewdoaizvjdavil` (`creatorId`,`provisional`),
  KEY `idx_uqninxavzosidwauevugnokfvdfdwsnkirot` (`saved`),
  KEY `fk_cgvrqkatxbtelugdvduaouotbgprpvdfriiq` (`canonicalId`),
  CONSTRAINT `fk_cgvrqkatxbtelugdvduaouotbgprpvdfriiq` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_osvxkigiptzdfuqnxtvlxbgmopfatogyfieg` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_wvqloaiscapzwbvkvvomwjnporlskpkofene` (`elementId`,`timestamp`,`userId`),
  KEY `fk_eefmidaxdiplwkhgagbfgqdrnfkkwptksxpi` (`userId`),
  KEY `fk_sirrjncrzflrjhuugonbpuddgyajpzocyedp` (`siteId`),
  KEY `fk_nimamevaulmxfdvuetwmgfpqwlarsclutmhn` (`draftId`),
  CONSTRAINT `fk_eefmidaxdiplwkhgagbfgqdrnfkkwptksxpi` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nimamevaulmxfdvuetwmgfpqwlarsclutmhn` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_puaddcxynpuameaxjtrwftluwniccjpqkitl` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sirrjncrzflrjhuugonbpuddgyajpzocyedp` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
INSERT INTO `elementactivity` VALUES (6,1,1,NULL,'edit','2024-05-01 10:52:12'),(6,1,1,NULL,'save','2024-05-01 10:52:14'),(12,1,1,NULL,'edit','2024-04-29 10:50:54'),(12,1,1,NULL,'save','2024-04-29 10:50:55'),(31,1,1,NULL,'save','2024-04-29 12:55:14');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_exbjihtpangdhkbrmhaudhfuxjxabbgsezik` (`dateDeleted`),
  KEY `idx_aqbozhjikjdenfxiyqrsjebszlhilkiafyrt` (`fieldLayoutId`),
  KEY `idx_drbygyimgqhdvjwtpnskfqyafpxrcjqacefw` (`type`),
  KEY `idx_cevmgliciikpoitbpumvejgndiglosownaqj` (`enabled`),
  KEY `idx_ifztnosxbloxvafvxtuyuservbfvxvbfixiz` (`canonicalId`),
  KEY `idx_esfbxogidepqvkfcsyeazvxctfbxbtbeqkeo` (`archived`,`dateCreated`),
  KEY `idx_ronuiptgdfujhwwuwzgahtncuuhqbkafvpxy` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_iksgwxpgiaznjbdyijalnajpnrbdrwjgzxsd` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_kdpmtgshfgkbbxlxnlkuqghkaoccnibdygfn` (`draftId`),
  KEY `fk_kiirwnenuaqsbzwkjlzijlrqqlkuusnikjeu` (`revisionId`),
  CONSTRAINT `fk_ghvgrdcmjqcuafucshsdbrmfkxwxsyxqbarn` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_kdpmtgshfgkbbxlxnlkuqghkaoccnibdygfn` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kiirwnenuaqsbzwkjlzijlrqqlkuusnikjeu` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zblvdrnkoymyltglfxlfsniadycunfeslseu` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-04-22 12:05:28','2024-04-22 12:05:28',NULL,NULL,NULL,'d536537b-c9e1-4023-b6a2-0c6b1771b9b5'),(2,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-04-22 12:07:43','2024-04-22 13:00:48',NULL,'2024-04-22 13:02:54',NULL,'1fbfccf8-a4d2-4135-bcef-ba1a0d11c9fa'),(3,2,NULL,1,1,'craft\\elements\\Entry',1,0,'2024-04-22 12:07:43','2024-04-22 12:07:43',NULL,NULL,NULL,'5c9da430-66be-4977-86c8-6883dfca8574'),(4,2,NULL,2,1,'craft\\elements\\Entry',1,0,'2024-04-22 12:45:59','2024-04-22 12:45:59',NULL,NULL,NULL,'1e6a0136-72b5-42c3-95b5-876761b76760'),(5,2,NULL,3,1,'craft\\elements\\Entry',1,0,'2024-04-22 13:00:48','2024-04-22 13:00:48',NULL,NULL,NULL,'45e68054-a45d-4011-bf5e-5234c95400ac'),(6,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-04-22 13:03:41','2024-05-01 10:52:14',NULL,NULL,NULL,'581e51d2-eee9-4040-b5ca-4bbaeb0ae640'),(7,6,NULL,4,2,'craft\\elements\\Entry',1,0,'2024-04-22 13:03:41','2024-04-22 13:03:41',NULL,NULL,NULL,'de87fe34-d2d1-4c0a-bea1-4da2f46a3e1d'),(8,6,NULL,5,2,'craft\\elements\\Entry',1,0,'2024-04-22 13:07:43','2024-04-22 13:07:43',NULL,NULL,NULL,'9295b806-5248-4a3d-99fe-b49cb3adf6eb'),(10,6,NULL,6,2,'craft\\elements\\Entry',1,0,'2024-04-22 13:21:00','2024-04-22 13:21:00',NULL,NULL,NULL,'5bcf67fa-f873-4fae-8e3a-90d5a5e8f920'),(11,6,NULL,7,2,'craft\\elements\\Entry',1,0,'2024-04-22 13:21:52','2024-04-22 13:21:52',NULL,NULL,NULL,'1202ca91-62b8-4186-a772-b63858d09ee0'),(12,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2024-04-29 10:47:47','2024-04-29 11:08:12',NULL,NULL,NULL,'155b3dd3-4266-4eea-9512-7bc748f44dec'),(13,12,NULL,8,4,'craft\\elements\\Entry',1,0,'2024-04-29 10:47:47','2024-04-29 10:47:47',NULL,NULL,NULL,'757094d5-b972-43ac-a191-fb09ebbcfc01'),(15,12,NULL,9,4,'craft\\elements\\Entry',1,0,'2024-04-29 10:50:41','2024-04-29 10:50:41',NULL,NULL,NULL,'2728e6de-097a-442a-9976-feeae3e3bd95'),(17,12,NULL,10,4,'craft\\elements\\Entry',1,0,'2024-04-29 10:50:55','2024-04-29 10:50:55',NULL,NULL,NULL,'92e17f94-4f26-438b-981b-922281d6b68a'),(18,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:41','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'e9fb9015-b48a-469f-8d3d-eeae5604594b'),(19,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:42','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'87eaa9f7-dbf5-4126-98fd-fb1846fdba5e'),(20,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:42','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'f77d58dc-898a-4d0d-8771-1e75727e3ef1'),(21,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:42','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'2901ef95-5214-4da5-871d-9a6bdf3ccfed'),(22,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:43','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'d87ca2a1-d2d6-4e2e-8af5-fc3bd36e1086'),(23,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:43','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'a8e1949d-ef87-41d5-b250-839def35ee6a'),(24,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:43','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'2fedb29c-fd1a-4cc7-b914-917166e0647e'),(25,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:43','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'6a92b7b4-d0a1-4ac3-94af-293926e554b1'),(26,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:44','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'81742061-bda0-4928-a433-03e1301d9b27'),(27,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:44','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'720ed714-64bc-409b-8791-c3804a8ec300'),(28,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:44','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'3b2111e3-4d66-4ab1-9ea9-67274bda80af'),(29,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:45','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'13f72aa8-2d33-4840-9157-58dba01f37ba'),(30,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:45','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'8b59a76d-7028-445d-b5c4-54e36e0e286d'),(31,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:45','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'536e3bae-7e35-44df-bdfa-b5108c132a64'),(32,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:46','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'de85757f-8c2b-444b-9960-9f2edf35eb94'),(33,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:46','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'1ca5f432-1679-4b77-97ee-95772e150053'),(34,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:46','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'0a293834-1b88-4bcf-a7b9-6b12b6530f29'),(35,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:47','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'7fff7668-07e8-4a2f-af28-1e677fed2281'),(36,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:47','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'3b11488e-fd45-4356-8acd-1d4b8869f7ec'),(37,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:48','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'1b5eae39-81b1-44c6-87a5-84fb2139ad81'),(38,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:49','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'3c6b10e3-ded2-4e5a-9df4-2b9360738cd6'),(39,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:49','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'3728371e-2d2d-48ee-a4e7-dd42556a407e'),(40,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:49','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'f589bb9b-4962-4ec3-a1c8-06faf494504c'),(41,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:50','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'2c6646c8-ecd6-4c21-a5b7-af1fead3e84a'),(42,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:50','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'2df2537c-b4ca-4c44-ad3c-842cbd6720a8'),(43,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:51','2024-04-29 13:11:23',NULL,'2024-04-29 13:11:23',NULL,'62bf38a6-95fb-4d60-a9b3-1ceaeb8fbd0b'),(44,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:53','2024-04-29 10:59:16',NULL,'2024-04-29 10:59:16',NULL,'0d58e21e-f9d3-46a0-9e05-d26dc273d983'),(45,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:53','2024-04-29 10:59:16',NULL,'2024-04-29 10:59:16',NULL,'f164d48e-446d-4885-bf2a-8f27236c5089'),(46,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:54','2024-04-29 10:59:17',NULL,'2024-04-29 10:59:17',NULL,'cb8abea5-9bd8-49fe-a275-9dfb2605d1b9'),(47,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:54','2024-04-29 10:59:17',NULL,'2024-04-29 10:59:17',NULL,'7d252fc0-4f9f-4b7c-91b5-55b492b2edad'),(48,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:54','2024-04-29 10:59:17',NULL,'2024-04-29 10:59:17',NULL,'b59191a7-8444-4779-8f28-64c5650695f6'),(49,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:55','2024-04-29 10:59:18',NULL,'2024-04-29 10:59:18',NULL,'6a100130-3973-4459-b158-a815cb32223a'),(50,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:55','2024-04-29 10:59:18',NULL,'2024-04-29 10:59:18',NULL,'6de9809a-1382-4b18-be26-dbd3b38ecdae'),(51,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:55','2024-04-29 10:59:18',NULL,'2024-04-29 10:59:18',NULL,'7b27d014-2372-485d-ac6b-e06987e896f6'),(52,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:56','2024-04-29 10:59:18',NULL,'2024-04-29 10:59:18',NULL,'4d097553-3546-43e4-8483-c9886c865580'),(53,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:56','2024-04-29 10:59:19',NULL,'2024-04-29 10:59:19',NULL,'a51547f4-0dc6-40e9-aee4-bb1b3139d647'),(54,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:56','2024-04-29 10:59:19',NULL,'2024-04-29 10:59:19',NULL,'bea1af33-cefd-4278-bfc2-e52cc782f3de'),(55,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:56','2024-04-29 10:59:19',NULL,'2024-04-29 10:59:19',NULL,'b718666d-26c2-49eb-adf9-458fce1b71b7'),(56,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:57','2024-04-29 10:59:20',NULL,'2024-04-29 10:59:20',NULL,'fa203c36-ea14-4edd-80f1-90d1576d72fd'),(57,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:57','2024-04-29 10:59:20',NULL,'2024-04-29 10:59:20',NULL,'0c398b58-b1db-4c7c-a5ee-e5eee6a4caa7'),(58,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:57','2024-04-29 10:59:20',NULL,'2024-04-29 10:59:20',NULL,'a0835124-1f4d-4d17-bd1c-ad88e20b0273'),(59,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:58','2024-04-29 10:59:21',NULL,'2024-04-29 10:59:21',NULL,'58bb081e-9f56-44af-bf8e-f5b9091c1d23'),(60,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:58','2024-04-29 10:59:21',NULL,'2024-04-29 10:59:21',NULL,'4cfbece8-d142-4508-8070-527a3b5077ec'),(61,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:59','2024-04-29 10:59:21',NULL,'2024-04-29 10:59:21',NULL,'c1e33902-aa31-4185-98f7-25b658a8b167'),(62,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:58:59','2024-04-29 10:59:22',NULL,'2024-04-29 10:59:22',NULL,'ee825332-cd59-4513-8d87-1bf1734a9134'),(63,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:59:00','2024-04-29 10:59:23',NULL,'2024-04-29 10:59:23',NULL,'a818b001-6b15-4140-90ce-a375dd56c85c'),(64,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:59:00','2024-04-29 10:59:23',NULL,'2024-04-29 10:59:23',NULL,'70b45a60-955d-42f7-ac56-d882fd214fee'),(65,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:59:01','2024-04-29 10:59:23',NULL,'2024-04-29 10:59:23',NULL,'49c6063b-cd1f-4f53-9151-efcd2e9dde6f'),(66,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:59:01','2024-04-29 10:59:23',NULL,'2024-04-29 10:59:23',NULL,'052a0fae-d228-4274-8801-6b4f22b96f4c'),(67,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:59:01','2024-04-29 10:59:24',NULL,'2024-04-29 10:59:24',NULL,'f38fef01-3796-4b08-9c43-f741b0c99584'),(68,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:59:02','2024-04-29 10:59:24',NULL,'2024-04-29 10:59:24',NULL,'49d89460-8df2-4675-bf3e-925039c0ed1e'),(69,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 10:59:02','2024-04-29 10:59:25',NULL,'2024-04-29 10:59:25',NULL,'ca241711-27e6-4220-9719-b8be80e802b8'),(70,12,NULL,11,4,'craft\\elements\\Entry',1,0,'2024-04-29 11:01:45','2024-04-29 11:01:45',NULL,NULL,NULL,'2cccf45b-ff18-426c-822a-80773f0e9935'),(71,12,NULL,12,4,'craft\\elements\\Entry',1,0,'2024-04-29 11:08:12','2024-04-29 11:08:12',NULL,NULL,NULL,'c4834f26-e273-4e84-b403-625498dedc19'),(72,6,NULL,13,2,'craft\\elements\\Entry',1,0,'2024-04-29 12:27:01','2024-04-29 12:27:01',NULL,NULL,NULL,'d2288769-19f9-462f-a417-b4a13e0d37ff'),(73,6,NULL,14,2,'craft\\elements\\Entry',1,0,'2024-04-29 12:27:22','2024-04-29 12:27:22',NULL,NULL,NULL,'4e605e93-3ca0-46f8-901d-89e566f2ed04'),(74,6,NULL,15,2,'craft\\elements\\Entry',1,0,'2024-04-29 12:36:36','2024-04-29 12:36:36',NULL,NULL,NULL,'dde946ef-390d-4eee-8232-2cbee0e60028'),(76,6,NULL,16,2,'craft\\elements\\Entry',1,0,'2024-04-29 12:40:11','2024-04-29 12:40:11',NULL,NULL,NULL,'40f4df0c-5769-4793-9c7e-e1df714fa29a'),(78,6,NULL,17,2,'craft\\elements\\Entry',1,0,'2024-04-29 12:42:41','2024-04-29 12:42:41',NULL,NULL,NULL,'5092aec1-301b-492c-b304-1538beaca5ed'),(80,6,NULL,18,2,'craft\\elements\\Entry',1,0,'2024-04-29 12:54:38','2024-04-29 12:54:38',NULL,NULL,NULL,'89fbb6ad-5c63-432e-b432-a256821b0b3e'),(81,6,NULL,19,2,'craft\\elements\\Entry',1,0,'2024-04-29 12:54:51','2024-04-29 12:54:51',NULL,NULL,NULL,'77303660-72f7-476e-9e51-0df921b33bdf'),(82,6,NULL,20,2,'craft\\elements\\Entry',1,0,'2024-04-29 12:55:18','2024-04-29 12:55:18',NULL,NULL,NULL,'07d7fbee-8d62-4478-80f9-a61563573e9a'),(83,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:33','2024-04-29 13:11:33',NULL,NULL,NULL,'d56e97fb-f17a-48ee-b86d-3604a56b6ce4'),(84,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:33','2024-04-29 13:11:33',NULL,NULL,NULL,'fc0e3cf6-2229-4c1a-a457-a114a1d7d078'),(85,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:33','2024-04-29 13:11:33',NULL,NULL,NULL,'ef962a5a-45d1-4311-8218-8f8252a698c7'),(86,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:34','2024-04-29 13:11:34',NULL,NULL,NULL,'75f17578-daf2-4cfa-916c-478f15240d67'),(87,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:34','2024-04-29 13:11:34',NULL,NULL,NULL,'98a88b25-67a0-447e-b2ec-ef109f88c171'),(88,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:34','2024-04-29 13:11:34',NULL,NULL,NULL,'676e00bb-4f17-4dc2-9837-175b15a70bd5'),(89,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:35','2024-04-29 13:11:35',NULL,NULL,NULL,'9154b18a-dfc7-4b3a-8102-578ed7ce6b27'),(90,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:35','2024-04-29 13:11:35',NULL,NULL,NULL,'beeaae03-e189-4f05-a535-eeefef287c9a'),(91,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:35','2024-04-29 13:11:35',NULL,NULL,NULL,'a64b4480-0d81-4277-9882-6e31ed7c5809'),(92,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:35','2024-04-29 13:11:35',NULL,NULL,NULL,'7e6d52ec-a835-4ed0-8bfd-29f5f543da11'),(93,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:36','2024-04-29 13:11:36',NULL,NULL,NULL,'e72ffe0c-e6b7-42f5-9922-9a89c7fe42fd'),(94,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:36','2024-04-29 13:11:36',NULL,NULL,NULL,'1c8690c5-4c26-4f0f-bed4-79c270d8ee22'),(95,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:36','2024-04-29 13:11:36',NULL,NULL,NULL,'c7a47e94-defa-49c2-986c-aa66ea86aebc'),(96,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:37','2024-04-29 13:11:37',NULL,NULL,NULL,'369ce3da-5f16-4237-adf4-c9be36bd4c81'),(97,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:37','2024-04-29 13:11:37',NULL,NULL,NULL,'fdbfe9d1-9dc8-4f23-9675-4303a9ae0dcf'),(98,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:37','2024-04-29 13:11:37',NULL,NULL,NULL,'3c39314c-fa01-4b64-a1b2-249aa3a522b9'),(99,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:38','2024-04-29 13:11:38',NULL,NULL,NULL,'d84fb8d6-5805-4429-9344-8a1badeb25d9'),(100,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:38','2024-04-29 13:11:38',NULL,NULL,NULL,'2dc9fcbf-1c50-48f4-9bd6-fc9037f4bfa5'),(101,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:38','2024-04-29 13:11:38',NULL,NULL,NULL,'609531ae-e431-4fba-9da5-9fea400ee610'),(102,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:40','2024-04-29 13:11:40',NULL,NULL,NULL,'21fd19b6-6e48-4079-af9a-a116099d156c'),(103,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:40','2024-04-29 13:11:40',NULL,NULL,NULL,'93e86d37-b6b8-4ede-92c4-be59b0cf8ca7'),(104,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:40','2024-04-29 13:11:40',NULL,NULL,NULL,'bea37f4c-202f-495c-915e-38b9aa1d11a7'),(105,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:41','2024-04-29 13:11:41',NULL,NULL,NULL,'a2f0e471-8af9-4e17-a75c-468a76bda4a2'),(106,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:41','2024-04-29 13:11:41',NULL,NULL,NULL,'5752b71e-bd91-4ebb-aa3c-efa0bd9ba8bc'),(107,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:41','2024-04-29 13:11:41',NULL,NULL,NULL,'e7ff4414-20aa-4ae3-9003-c70df09521e9'),(108,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:42','2024-04-29 13:11:42',NULL,NULL,NULL,'fd5eab31-ca5f-4772-8142-80a89420fa7f'),(109,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-04-29 13:11:42','2024-04-29 13:12:04',NULL,'2024-04-29 13:12:04',NULL,'4879863f-dba7-43f8-9d7e-2d5aa83f3e02'),(111,6,NULL,21,2,'craft\\elements\\Entry',1,0,'2024-04-29 13:18:34','2024-04-29 13:18:34',NULL,NULL,NULL,'dafd3f5d-31dc-4db9-a382-3a5d7e197f71'),(113,6,NULL,22,2,'craft\\elements\\Entry',1,0,'2024-04-30 21:02:04','2024-04-30 21:02:04',NULL,NULL,NULL,'2669f8d7-1858-4e62-86bf-0688df280b5e'),(114,6,NULL,23,2,'craft\\elements\\Entry',1,0,'2024-04-30 21:09:09','2024-04-30 21:09:09',NULL,NULL,NULL,'58273ffc-451c-4b80-a102-6831daf04071'),(115,6,NULL,24,2,'craft\\elements\\Entry',1,0,'2024-05-01 00:17:31','2024-05-01 00:17:31',NULL,NULL,NULL,'c02f5671-3eff-47c9-93e5-f1368d87e130'),(116,6,NULL,25,2,'craft\\elements\\Entry',1,0,'2024-05-01 00:18:56','2024-05-01 00:18:56',NULL,NULL,NULL,'f98ae757-87b4-4f2c-a815-bd156d6ecc39'),(118,6,NULL,26,2,'craft\\elements\\Entry',1,0,'2024-05-01 01:05:24','2024-05-01 01:05:24',NULL,NULL,NULL,'dae0f64f-97cb-4a37-990d-635cdd758e0e'),(120,6,NULL,27,2,'craft\\elements\\Entry',1,0,'2024-05-01 10:44:37','2024-05-01 10:44:37',NULL,NULL,NULL,'5a372cc9-5d5c-4670-9717-669baa5e90df'),(121,6,NULL,28,2,'craft\\elements\\Entry',1,0,'2024-05-01 10:47:46','2024-05-01 10:47:46',NULL,NULL,NULL,'344a8d57-34d7-4311-8317-868c883fb937'),(123,6,NULL,29,2,'craft\\elements\\Entry',1,0,'2024-05-01 10:52:14','2024-05-01 10:52:14',NULL,NULL,NULL,'8fadb948-b25a-452a-922e-da3c176a5e98'),(124,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-05-01 11:52:45','2024-05-01 11:52:45',NULL,NULL,NULL,'aab7c517-c7ee-4a42-b957-712944262742');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_fxwhohnurprcmvbndiqiqgsngskynurqginj` (`timestamp`),
  CONSTRAINT `fk_xkkvrzdxfzstmmkapppcdzldacyfmjfidchs` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_lelsizfaiarmpvyntdbrjmxadnbjyrpwrzhm` (`ownerId`),
  CONSTRAINT `fk_gdyotofbutcljhdmbuinbhtnvojufzecygdv` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lelsizfaiarmpvyntdbrjmxadnbjyrpwrzhm` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gvedsnmdohwumwemrxxrmiqnkcazqoehzvvj` (`elementId`,`siteId`),
  KEY `idx_ywaeyqycphpetvitmqjudnnlaclxhkswiymi` (`siteId`),
  KEY `idx_utciijtuobuepboonqzzhehpvyvlveqcjejt` (`title`,`siteId`),
  KEY `idx_crnebbukkzgzytuvdjdbmkemlfirkadgthgm` (`slug`,`siteId`),
  KEY `idx_ceeuiiprlmbfbusooubckadibzqmkcaxlfwf` (`enabled`),
  KEY `idx_anbkohuyjtrncxyxzrkmajkhfxzslpoyrapo` (`uri`,`siteId`),
  CONSTRAINT `fk_dtniuneetqzdbiziedgcrfwxhjxestmkjrao` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xszuopjanrvwysxmfwyxjiyttnwrxvtgdozg` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,NULL,NULL,1,'2024-04-22 12:05:28','2024-04-22 12:05:28','e4b4bd0c-e823-4b79-b941-1550584774dd'),(2,2,1,'Startpagina','startpagina','__home__',NULL,1,'2024-04-22 12:07:43','2024-04-22 12:07:43','526dcc96-9cfb-424b-a25e-8cb86b7d9d1e'),(3,3,1,'Startpagina','startpagina','__home__',NULL,1,'2024-04-22 12:07:43','2024-04-22 12:07:43','fafe4598-1d20-47f1-b5c6-3fb65e1a1064'),(4,4,1,'Startpagina','startpagina','__home__',NULL,1,'2024-04-22 12:45:59','2024-04-22 12:45:59','d41695c1-259d-489b-9b24-987f0ce21f43'),(5,5,1,'Startpagina','startpagina','__home__',NULL,1,'2024-04-22 13:00:48','2024-04-22 13:00:48','624c0e7d-863a-41ff-a030-1876f9f10d86'),(6,6,1,'Startpagina','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"TEST - Intro: We deliver clarity, silence, a bridge between the rhythms of modernity and the timeless grace of a bygone age. Let AURO become an extension of you, enriching life and proving that in the midst of the cacophony, music could be a sanctuary, and innovation could be a timeless marvel.\", \"0cb30b4a-3841-418c-8856-ea680bb04022\": \"Find your vibe.\", \"17b30490-3b87-4158-a261-8e528b82c667\": \"AURO is your companion forward.\", \"22739534-4086-4c5f-80b4-8dffad3c0937\": \"Feel the Future.\", \"72d7ee56-dc44-4879-a506-665a7d450161\": \"You\'ve never felt like this before.\", \"822a27b1-5720-4c5a-9848-1e1602fd2cca\": \"We deliver clarity, a bridge between the rhythms of modernity and tradition. Let AURO become an extension of you, enriching life and proving that in the midst of the cacophony, music could be a sanctuary, and innovation could be a timeless marvel.\"}',1,'2024-04-22 13:03:41','2024-05-01 10:52:14','294bc23b-a907-41e8-a690-fc6b4c7dcb71'),(7,7,1,'homepage','homepage','__home__',NULL,1,'2024-04-22 13:03:41','2024-04-22 13:03:41','d6302b6e-ffbd-4f85-9131-fc500c6ce659'),(8,8,1,'homepage','homepage','__home__',NULL,1,'2024-04-22 13:07:43','2024-04-22 13:07:43','7f1340d1-356f-43af-8898-00777a4ac4f9'),(10,10,1,'homepage','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"Dit is een introtekst.\"}',1,'2024-04-22 13:21:00','2024-04-22 13:21:00','128b68a3-59e0-4df7-8214-1be1de268c02'),(11,11,1,'homepage','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"Dit is een introtekst - TEST TEST TEST.\"}',1,'2024-04-22 13:21:52','2024-04-22 13:21:52','6aecc8c3-213b-4cbf-803e-bc2303e16427'),(12,12,1,'Over ons','about','about',NULL,1,'2024-04-29 10:47:47','2024-04-29 10:50:55','532c4a2e-9e53-4af9-b5a4-1a88c94c99c7'),(13,13,1,'about','about','about',NULL,1,'2024-04-29 10:47:47','2024-04-29 10:47:47','7f8ce8f1-3e0d-4c5b-a88b-5b8523323679'),(15,15,1,'This is the About page title.','about','about',NULL,1,'2024-04-29 10:50:41','2024-04-29 10:50:41','3f13dcb2-6ecb-4d0a-b667-e7f581b8bef6'),(17,17,1,'Over ons','about','about',NULL,1,'2024-04-29 10:50:55','2024-04-29 10:50:55','2ca18085-052e-418b-aefe-3b831e168a79'),(18,18,1,'Pods case 4',NULL,NULL,NULL,1,'2024-04-29 10:58:41','2024-04-29 10:58:41','db6c0b36-bfd8-4845-ba00-2ec26ee3c461'),(19,19,1,'Pods case 3',NULL,NULL,NULL,1,'2024-04-29 10:58:42','2024-04-29 10:58:42','53e564d2-176a-4d62-be5e-aafa1da50a8c'),(20,20,1,'Pods case 2',NULL,NULL,NULL,1,'2024-04-29 10:58:42','2024-04-29 10:58:42','64a98bc3-0f83-4d6d-858f-cb502dbd2bb0'),(21,21,1,'Pods case 1',NULL,NULL,NULL,1,'2024-04-29 10:58:42','2024-04-29 10:58:42','e6a38d5f-422f-4c28-ad3a-cea021a5f2c3'),(22,22,1,'Pods 9',NULL,NULL,NULL,1,'2024-04-29 10:58:43','2024-04-29 10:58:43','f0764356-88da-4e64-bdb4-f25b3b788bdd'),(23,23,1,'Pods 8',NULL,NULL,NULL,1,'2024-04-29 10:58:43','2024-04-29 10:58:43','02d020a4-e550-432a-94c3-fdc291f47029'),(24,24,1,'Pods 7',NULL,NULL,NULL,1,'2024-04-29 10:58:43','2024-04-29 10:58:43','0130c522-6754-4673-96b9-adb75143544a'),(25,25,1,'Pods 6',NULL,NULL,NULL,1,'2024-04-29 10:58:43','2024-04-29 10:58:43','d5c84caa-b7ef-4301-9559-bbc9d4534f70'),(26,26,1,'Pods 5',NULL,NULL,NULL,1,'2024-04-29 10:58:44','2024-04-29 10:58:44','2c97facd-d6e6-432b-b05f-66e537196ff0'),(27,27,1,'Pods 4',NULL,NULL,NULL,1,'2024-04-29 10:58:44','2024-04-29 10:58:44','e2ab9b04-c937-4322-a213-df0c12d3933a'),(28,28,1,'Pods 3',NULL,NULL,NULL,1,'2024-04-29 10:58:44','2024-04-29 10:58:44','cd2bcc62-8713-4f76-b25c-808590788294'),(29,29,1,'Pods 2',NULL,NULL,NULL,1,'2024-04-29 10:58:45','2024-04-29 10:58:45','fa3750dc-72cd-40f3-848a-c2c8275318b8'),(30,30,1,'Pods 1',NULL,NULL,NULL,1,'2024-04-29 10:58:45','2024-04-29 10:58:45','11cf990f-c45a-4614-bccc-593b55b3aeb8'),(31,31,1,'Bg 2',NULL,NULL,NULL,1,'2024-04-29 10:58:45','2024-04-29 10:58:45','814dd37f-a0c2-4d81-81f6-55155274217e'),(32,32,1,'Bg 1',NULL,NULL,NULL,1,'2024-04-29 10:58:46','2024-04-29 10:58:46','baa15597-013d-43c1-ba28-b2ecf6d80d40'),(33,33,1,'Aurowatch 1',NULL,NULL,NULL,1,'2024-04-29 10:58:46','2024-04-29 10:58:46','d5737306-9304-4d63-b387-ca4cef7d5ca0'),(34,34,1,'Aurovision 3',NULL,NULL,NULL,1,'2024-04-29 10:58:46','2024-04-29 10:58:46','daf40175-9060-412b-b3b0-f63c4518b42a'),(35,35,1,'Aurovision 2',NULL,NULL,NULL,1,'2024-04-29 10:58:47','2024-04-29 10:58:47','93a429c6-c7a3-4960-aa4a-db951a223d60'),(36,36,1,'Aurovision 1',NULL,NULL,NULL,1,'2024-04-29 10:58:47','2024-04-29 10:58:47','553ca8f4-c0a2-4759-9870-276a73830a68'),(37,37,1,'Aurotouch 1',NULL,NULL,NULL,1,'2024-04-29 10:58:48','2024-04-29 10:58:48','a007b72d-0e8b-4b8e-ab71-6ad72f6e6aad'),(38,38,1,'Aurotags 1',NULL,NULL,NULL,1,'2024-04-29 10:58:49','2024-04-29 10:58:49','c22f31ad-84a1-4b7f-abe3-d05797812433'),(39,39,1,'Auroport 1',NULL,NULL,NULL,1,'2024-04-29 10:58:49','2024-04-29 10:58:49','5e5a1d74-012a-44dd-9d7f-348a6f414e1e'),(40,40,1,'Aurolink 4',NULL,NULL,NULL,1,'2024-04-29 10:58:49','2024-04-29 10:58:49','ebc4e92e-14d7-4207-9fb2-0688ef692aac'),(41,41,1,'Aurolink 3',NULL,NULL,NULL,1,'2024-04-29 10:58:50','2024-04-29 10:58:50','e67ad512-68aa-4974-80e3-639adcec8ac9'),(42,42,1,'Aurolink 2',NULL,NULL,NULL,1,'2024-04-29 10:58:50','2024-04-29 10:58:50','48fc000f-6539-4800-85c3-322a29e34767'),(43,43,1,'Aurolink 1',NULL,NULL,NULL,1,'2024-04-29 10:58:51','2024-04-29 10:58:51','e8c44602-2b53-46e0-b7fc-02db4d8ffab6'),(44,44,1,'Pods case 4',NULL,NULL,NULL,1,'2024-04-29 10:58:53','2024-04-29 10:58:53','63146566-36e3-4f13-a939-59ee8c0a45a8'),(45,45,1,'Pods case 3',NULL,NULL,NULL,1,'2024-04-29 10:58:53','2024-04-29 10:58:53','2209020a-727a-4671-ba6c-e620bcf64936'),(46,46,1,'Pods case 2',NULL,NULL,NULL,1,'2024-04-29 10:58:54','2024-04-29 10:58:54','5c548c3a-3bfe-427a-8757-df9938e17a11'),(47,47,1,'Pods case 1',NULL,NULL,NULL,1,'2024-04-29 10:58:54','2024-04-29 10:58:54','b7e815e9-30db-438c-ae96-487f1c30efa2'),(48,48,1,'Pods 9',NULL,NULL,NULL,1,'2024-04-29 10:58:54','2024-04-29 10:58:54','ac67e72f-4ecb-4594-b2d9-e0f290a5e87c'),(49,49,1,'Pods 8',NULL,NULL,NULL,1,'2024-04-29 10:58:55','2024-04-29 10:58:55','55f8e179-4a86-46da-9b5e-46fa36981c60'),(50,50,1,'Pods 7',NULL,NULL,NULL,1,'2024-04-29 10:58:55','2024-04-29 10:58:55','6f48245c-2f2f-4936-91e6-a29134b2aa06'),(51,51,1,'Pods 6',NULL,NULL,NULL,1,'2024-04-29 10:58:55','2024-04-29 10:58:55','77eb7a5c-2084-4b64-b9be-a4e408736a34'),(52,52,1,'Pods 5',NULL,NULL,NULL,1,'2024-04-29 10:58:56','2024-04-29 10:58:56','24b3e8db-2574-459d-8c85-e9b8fea842b2'),(53,53,1,'Pods 4',NULL,NULL,NULL,1,'2024-04-29 10:58:56','2024-04-29 10:58:56','a578a7e1-e04a-4098-ae6a-1bc91fed49e8'),(54,54,1,'Pods 3',NULL,NULL,NULL,1,'2024-04-29 10:58:56','2024-04-29 10:58:56','a6661f61-3125-472a-a320-13ac1727f675'),(55,55,1,'Pods 2',NULL,NULL,NULL,1,'2024-04-29 10:58:56','2024-04-29 10:58:56','900269af-f1ab-45a3-b8b6-36f122c68fb9'),(56,56,1,'Pods 1',NULL,NULL,NULL,1,'2024-04-29 10:58:57','2024-04-29 10:58:57','3adfc986-a7c9-4fcb-99da-831fe4667018'),(57,57,1,'Bg 2',NULL,NULL,NULL,1,'2024-04-29 10:58:57','2024-04-29 10:58:57','5c451fb1-2d44-4d04-935e-98c5709e226c'),(58,58,1,'Bg 1',NULL,NULL,NULL,1,'2024-04-29 10:58:57','2024-04-29 10:58:57','5e9a37d4-562c-413b-ac3c-41e7d3538238'),(59,59,1,'Aurowatch 1',NULL,NULL,NULL,1,'2024-04-29 10:58:58','2024-04-29 10:58:58','54a06c1f-4e30-4db3-bce8-ad2cb4036649'),(60,60,1,'Aurovision 3',NULL,NULL,NULL,1,'2024-04-29 10:58:58','2024-04-29 10:58:58','41440738-83cf-48de-ba3a-2038c83659be'),(61,61,1,'Aurovision 2',NULL,NULL,NULL,1,'2024-04-29 10:58:59','2024-04-29 10:58:59','aa7fdbc2-5ad2-4a81-9ba7-cf92207aab86'),(62,62,1,'Aurovision 1',NULL,NULL,NULL,1,'2024-04-29 10:58:59','2024-04-29 10:58:59','942a8911-2c29-4153-bb26-e64597d4d163'),(63,63,1,'Aurotouch 1',NULL,NULL,NULL,1,'2024-04-29 10:59:00','2024-04-29 10:59:00','3e41e177-46dc-41c6-85a2-8613a4262d93'),(64,64,1,'Aurotags 1',NULL,NULL,NULL,1,'2024-04-29 10:59:00','2024-04-29 10:59:00','223ca0e8-1ebf-4e0e-91c9-de3ee40a16a2'),(65,65,1,'Auroport 1',NULL,NULL,NULL,1,'2024-04-29 10:59:01','2024-04-29 10:59:01','62cb6f98-aa7c-4001-9b05-05f21efb6044'),(66,66,1,'Aurolink 4',NULL,NULL,NULL,1,'2024-04-29 10:59:01','2024-04-29 10:59:01','013197ac-332e-4c6a-ab7d-549111023efc'),(67,67,1,'Aurolink 3',NULL,NULL,NULL,1,'2024-04-29 10:59:01','2024-04-29 10:59:01','e5c85d9c-70b2-43de-8505-fd5de433704d'),(68,68,1,'Aurolink 2',NULL,NULL,NULL,1,'2024-04-29 10:59:02','2024-04-29 10:59:02','25396ff2-1b10-44e6-b18e-3eae9e4154bc'),(69,69,1,'Aurolink 1',NULL,NULL,NULL,1,'2024-04-29 10:59:02','2024-04-29 10:59:02','34cbc85d-adb0-4f5d-966a-e5ae10aaedce'),(70,70,1,'Over ons','about','about',NULL,1,'2024-04-29 11:01:45','2024-04-29 11:01:45','79f93d36-5fbe-4074-b1fc-712abaf4b0b6'),(71,71,1,'Over ons','about','about',NULL,1,'2024-04-29 11:08:12','2024-04-29 11:08:12','57971b48-b20a-4c46-baf2-62c09f5cb8b3'),(72,72,1,'homepage','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"Dit is een introtekst - TEST TEST TEST.\"}',1,'2024-04-29 12:27:01','2024-04-29 12:27:01','b348c6ae-7813-4ad6-89a2-2fd631713cfd'),(73,73,1,'homepage','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"Dit is een introtekst - TEST TEST TEST.\"}',1,'2024-04-29 12:27:22','2024-04-29 12:27:22','30dfdd80-039b-4897-a7cd-7e01d661e60c'),(74,74,1,'homepage','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"Dit is een introtekst - TEST TEST TEST.\"}',1,'2024-04-29 12:36:36','2024-04-29 12:36:36','866419c8-eb7a-41de-99d3-567482c2f9e2'),(76,76,1,NULL,'homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"Dit is een introtekst - TEST TEST TEST.\", \"0cb30b4a-3841-418c-8856-ea680bb04022\": \"Snaky Sneakers\", \"72d7ee56-dc44-4879-a506-665a7d450161\": \"Find your preferred sneakers now.\"}',1,'2024-04-29 12:40:11','2024-04-29 12:40:11','71931ae9-853f-4ba6-8344-4304388897a9'),(78,78,1,'Startpagina','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"Dit is een introtekst - TEST TEST TEST.\", \"0cb30b4a-3841-418c-8856-ea680bb04022\": \"Snaky Sneakers\", \"72d7ee56-dc44-4879-a506-665a7d450161\": \"Find your preferred sneakers now.\"}',1,'2024-04-29 12:42:41','2024-04-29 12:42:41','5ba53985-6b2d-4497-ab42-b6bfdf08bf11'),(80,80,1,'Startpagina','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"Dit is een introtekst - TEST TEST TEST.\", \"0cb30b4a-3841-418c-8856-ea680bb04022\": \"Snaky Sneakers\", \"72d7ee56-dc44-4879-a506-665a7d450161\": \"Find your preferred sneakers now.\"}',1,'2024-04-29 12:54:38','2024-04-29 12:54:38','94ab3db6-2db7-4c1a-8c8a-782504c6ecdf'),(81,81,1,'Startpagina','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"Dit is een introtekst - TEST TEST TEST.\", \"0cb30b4a-3841-418c-8856-ea680bb04022\": \"Snaky Sneakers\", \"72d7ee56-dc44-4879-a506-665a7d450161\": \"Find your preferred sneakers now.\"}',1,'2024-04-29 12:54:51','2024-04-29 12:54:51','51fbb7fd-ec21-47fd-b486-11fb3cb13de2'),(82,82,1,'Startpagina','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"Dit is een introtekst - TEST TEST TEST.\", \"0cb30b4a-3841-418c-8856-ea680bb04022\": \"Snaky Sneakers\", \"72d7ee56-dc44-4879-a506-665a7d450161\": \"Find your preferred sneakers now.\"}',1,'2024-04-29 12:55:18','2024-04-29 12:55:18','91b55876-4de1-44d8-8ec0-3dca42e4e274'),(83,83,1,'Pods 6',NULL,NULL,NULL,1,'2024-04-29 13:11:33','2024-04-29 13:11:33','6c21c291-f297-4cb3-886b-5eef7668c69b'),(84,84,1,'Pods case 4',NULL,NULL,NULL,1,'2024-04-29 13:11:33','2024-04-29 13:11:33','6fcbd6e0-652f-45de-800e-4250b2ea7f0b'),(85,85,1,'Pods case 3',NULL,NULL,NULL,1,'2024-04-29 13:11:33','2024-04-29 13:11:33','1be8210e-4753-4567-9e23-d8419f846066'),(86,86,1,'Pods case 2',NULL,NULL,NULL,1,'2024-04-29 13:11:34','2024-04-29 13:11:34','80333142-6098-46de-bf77-2089cd1f117c'),(87,87,1,'Pods case 1',NULL,NULL,NULL,1,'2024-04-29 13:11:34','2024-04-29 13:11:34','ddcc4fad-905c-4ab6-afaa-72dc8b1bffcb'),(88,88,1,'Pods 9',NULL,NULL,NULL,1,'2024-04-29 13:11:34','2024-04-29 13:11:34','2cb65656-23c2-4f11-812f-649aaeebabcb'),(89,89,1,'Pods 8',NULL,NULL,NULL,1,'2024-04-29 13:11:35','2024-04-29 13:11:35','4b3d569f-7acd-40a6-bac0-862a7505b231'),(90,90,1,'Pods 7',NULL,NULL,NULL,1,'2024-04-29 13:11:35','2024-04-29 13:11:35','e818e38e-840a-472f-8f86-6b696d710eff'),(91,91,1,'Pods 5',NULL,NULL,NULL,1,'2024-04-29 13:11:35','2024-04-29 13:11:35','3dc1ce5e-3071-4678-bc1c-1fe36dc90b80'),(92,92,1,'Pods 4',NULL,NULL,NULL,1,'2024-04-29 13:11:35','2024-04-29 13:11:35','621215c3-b3b7-4cf3-8dcb-2b5bc3862706'),(93,93,1,'Pods 3',NULL,NULL,NULL,1,'2024-04-29 13:11:36','2024-04-29 13:11:36','fa0080ec-a7c5-411e-a5e6-80ffcfa28214'),(94,94,1,'Pods 2',NULL,NULL,NULL,1,'2024-04-29 13:11:36','2024-04-29 13:11:36','de5a886f-3489-4f92-a4bc-ccf766c56401'),(95,95,1,'Pods 1',NULL,NULL,NULL,1,'2024-04-29 13:11:36','2024-04-29 13:11:36','76da2ebe-5aec-4d29-bcd3-7553ff8a3def'),(96,96,1,'Bg 2',NULL,NULL,NULL,1,'2024-04-29 13:11:37','2024-04-29 13:11:37','2c4760eb-3b8a-46bb-9261-d9f7f6ac6c29'),(97,97,1,'Bg 1',NULL,NULL,NULL,1,'2024-04-29 13:11:37','2024-04-29 13:11:37','77838443-5723-4263-a99a-92fdde4d35d8'),(98,98,1,'Aurowatch 1',NULL,NULL,NULL,1,'2024-04-29 13:11:37','2024-04-29 13:11:37','bf6ffcc8-31bb-49ac-9685-8eef2e6b3a23'),(99,99,1,'Aurovision 3',NULL,NULL,NULL,1,'2024-04-29 13:11:38','2024-04-29 13:11:38','b473af6d-7ff0-4d58-97de-9bed7559d430'),(100,100,1,'Aurovision 2',NULL,NULL,NULL,1,'2024-04-29 13:11:38','2024-04-29 13:11:38','09ee14ce-e073-4120-a73e-96933fe80905'),(101,101,1,'Aurovision 1',NULL,NULL,NULL,1,'2024-04-29 13:11:38','2024-04-29 13:11:38','9fa0903a-4441-49b6-9dc5-c404e9cde315'),(102,102,1,'Aurotouch 1',NULL,NULL,NULL,1,'2024-04-29 13:11:40','2024-04-29 13:11:40','9e8bed59-f55a-457c-9bd9-f3ab9c218e4b'),(103,103,1,'Aurotags 1',NULL,NULL,NULL,1,'2024-04-29 13:11:40','2024-04-29 13:11:40','6f5ce936-7e85-47bb-9bc4-67176181407c'),(104,104,1,'Auroport 1',NULL,NULL,NULL,1,'2024-04-29 13:11:40','2024-04-29 13:11:40','cad7cd49-8764-4a22-8518-538073e80019'),(105,105,1,'Aurolink 4',NULL,NULL,NULL,1,'2024-04-29 13:11:41','2024-04-29 13:11:41','07cd029e-1bfe-4526-833c-c12e4901ba6a'),(106,106,1,'Aurolink 3',NULL,NULL,NULL,1,'2024-04-29 13:11:41','2024-04-29 13:11:41','9a42fe1c-03af-4745-bf24-131c85546a89'),(107,107,1,'Aurolink 2',NULL,NULL,NULL,1,'2024-04-29 13:11:41','2024-04-29 13:11:41','68637e45-8965-46c2-98a2-93a357bae7e4'),(108,108,1,'Aurolink 1',NULL,NULL,NULL,1,'2024-04-29 13:11:42','2024-04-29 13:11:42','a616f0ac-c628-4c1a-b850-50b4ce84b9d2'),(109,109,1,'Auro vid1',NULL,NULL,NULL,1,'2024-04-29 13:11:42','2024-04-29 13:11:42','6a6331cd-5d10-4e42-b33a-a06145899dfa'),(111,111,1,'Startpagina','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"Snaky Sneakers -- TestTest -- Introductietekst.\", \"0cb30b4a-3841-418c-8856-ea680bb04022\": \"Snaky Sneakers\", \"72d7ee56-dc44-4879-a506-665a7d450161\": \"Find your preferred sneakers now.\"}',1,'2024-04-29 13:18:34','2024-04-29 13:18:34','c3c98aff-7232-4147-b912-a6b7273c7149'),(113,113,1,'Startpagina','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"AURO Homepage -- Test -- Intro text lorem ipsum dolor sit amet consectetur nobis.\", \"0cb30b4a-3841-418c-8856-ea680bb04022\": \"AURO\", \"72d7ee56-dc44-4879-a506-665a7d450161\": \"The best auro website yet.\"}',1,'2024-04-30 21:02:04','2024-04-30 21:02:04','a08aaceb-2027-446b-80c5-c923a4ec9420'),(114,114,1,'Startpagina','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"AURO Homepage -- Test -- Intro text lorem ipsum dolor sit amet consectetur nobis.\", \"0cb30b4a-3841-418c-8856-ea680bb04022\": \"AURO\", \"72d7ee56-dc44-4879-a506-665a7d450161\": \"The best auro website yet.\"}',1,'2024-04-30 21:09:09','2024-04-30 21:09:09','5afd466f-df5f-4526-b4f2-c463ced75d20'),(115,115,1,'Startpagina','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"AURO Homepage -- Test -- Intro text lorem ipsum dolor sit amet consectetur nobis.\", \"0cb30b4a-3841-418c-8856-ea680bb04022\": \"AURO\", \"72d7ee56-dc44-4879-a506-665a7d450161\": \"The best auro website yet.\"}',1,'2024-05-01 00:17:31','2024-05-01 00:17:31','ffd4b358-b2a2-49a7-9a35-9a9f7e5ed56e'),(116,116,1,'Startpagina','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"AURO Homepage -- Test -- Intro text lorem ipsum dolor sit amet consectetur nobis.\", \"0cb30b4a-3841-418c-8856-ea680bb04022\": \"AURO\", \"72d7ee56-dc44-4879-a506-665a7d450161\": \"The best auro website yet.\"}',1,'2024-05-01 00:18:56','2024-05-01 00:18:56','1f756b33-7053-4859-8463-693ff6fc52ad'),(118,118,1,'Startpagina','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"AURO Homepage -- Test -- Intro text lorem ipsum dolor sit amet consectetur nobis.\", \"0cb30b4a-3841-418c-8856-ea680bb04022\": \"Find your vibe.\", \"72d7ee56-dc44-4879-a506-665a7d450161\": \"You\'ve never felt like this before.\"}',1,'2024-05-01 01:05:24','2024-05-01 01:05:24','07babac2-543e-41b7-ae94-fa9d5dde77d5'),(120,120,1,'Startpagina','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"TEST - Intro: We deliver clarity, silence, a bridge between the rhythms of modernity and the timeless grace of a bygone age. Let AURO become an extension of you, enriching life and proving that in the midst of the cacophony, music could be a sanctuary, and innovation could be a timeless marvel.\", \"0cb30b4a-3841-418c-8856-ea680bb04022\": \"Find your vibe.\", \"72d7ee56-dc44-4879-a506-665a7d450161\": \"You\'ve never felt like this before.\"}',1,'2024-05-01 10:44:37','2024-05-01 10:44:37','c029afec-82e9-42ed-922f-1adf1b1b17c4'),(121,121,1,'Startpagina','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"TEST - Intro: We deliver clarity, silence, a bridge between the rhythms of modernity and the timeless grace of a bygone age. Let AURO become an extension of you, enriching life and proving that in the midst of the cacophony, music could be a sanctuary, and innovation could be a timeless marvel.\", \"0cb30b4a-3841-418c-8856-ea680bb04022\": \"Find your vibe.\", \"72d7ee56-dc44-4879-a506-665a7d450161\": \"You\'ve never felt like this before.\"}',1,'2024-05-01 10:47:46','2024-05-01 10:47:46','6ba61876-0554-48c7-9229-8476f2cf2fb3'),(123,123,1,'Startpagina','homepage','__home__','{\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\": \"TEST - Intro: We deliver clarity, silence, a bridge between the rhythms of modernity and the timeless grace of a bygone age. Let AURO become an extension of you, enriching life and proving that in the midst of the cacophony, music could be a sanctuary, and innovation could be a timeless marvel.\", \"0cb30b4a-3841-418c-8856-ea680bb04022\": \"Find your vibe.\", \"17b30490-3b87-4158-a261-8e528b82c667\": \"AURO is your companion forward.\", \"22739534-4086-4c5f-80b4-8dffad3c0937\": \"Feel the Future.\", \"72d7ee56-dc44-4879-a506-665a7d450161\": \"You\'ve never felt like this before.\", \"822a27b1-5720-4c5a-9848-1e1602fd2cca\": \"We deliver clarity, a bridge between the rhythms of modernity and tradition. Let AURO become an extension of you, enriching life and proving that in the midst of the cacophony, music could be a sanctuary, and innovation could be a timeless marvel.\"}',1,'2024-05-01 10:52:14','2024-05-01 10:52:14','a4c972ec-f46c-4965-ac87-f72680ff3b5d'),(124,124,1,'Auro vid1',NULL,NULL,NULL,1,'2024-05-01 11:52:45','2024-05-01 11:52:45','97d07355-8008-44d3-9ce1-7b73e35d58b1');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_jqlsrdxlxuegtaqvdzacugwnkaqzbtotuahd` (`postDate`),
  KEY `idx_ihdmbuvxjpcpeifoyikhloclpicxshmzaumq` (`expiryDate`),
  KEY `idx_eczftkcxuhjzpfpbspajhlscvhmcduiccxds` (`sectionId`),
  KEY `idx_fnllxmfqrdojnixyhctkuxhcqvrjrzhljdgv` (`typeId`),
  KEY `idx_furenxddottgdponxkqscuawuworcrfzfvjk` (`primaryOwnerId`),
  KEY `idx_ajyfeznhyibqvhlykgwittbbapvfiopmcayz` (`fieldId`),
  KEY `fk_qtskbrvdtbwjzbehvdydpmpeldljtabwcbaa` (`parentId`),
  CONSTRAINT `fk_burxbufhybfouvdpoltcgtuocnjjpvunlusu` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hluzfxpyroymejzyzauiyasudaltyidgxqql` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iyznbxuqrckjsskfrcuuloflybrxgniudvdf` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_khgfmykgvxdmtygcvrbjbqdqkynohftczozf` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qtskbrvdtbwjzbehvdydpmpeldljtabwcbaa` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xqattsbhdxglpzmufozkmooqqhukpdnqyvnc` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (2,1,NULL,NULL,NULL,1,'2024-04-22 12:07:00',NULL,1,'2024-04-22 12:07:43','2024-04-22 12:07:43'),(3,1,NULL,NULL,NULL,1,'2024-04-22 12:07:00',NULL,NULL,'2024-04-22 12:07:43','2024-04-22 12:07:43'),(4,1,NULL,NULL,NULL,1,'2024-04-22 12:07:00',NULL,NULL,'2024-04-22 12:45:59','2024-04-22 12:45:59'),(5,1,NULL,NULL,NULL,1,'2024-04-22 12:07:00',NULL,NULL,'2024-04-22 13:00:48','2024-04-22 13:00:48'),(6,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-04-22 13:03:41','2024-04-22 13:03:41'),(7,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-04-22 13:03:41','2024-04-22 13:03:41'),(8,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-04-22 13:07:43','2024-04-22 13:07:43'),(10,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-04-22 13:21:00','2024-04-22 13:21:00'),(11,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-04-22 13:21:52','2024-04-22 13:21:52'),(12,2,NULL,NULL,NULL,3,'2024-04-29 10:47:00',NULL,NULL,'2024-04-29 10:47:47','2024-04-29 10:47:47'),(13,2,NULL,NULL,NULL,3,'2024-04-29 10:47:00',NULL,NULL,'2024-04-29 10:47:47','2024-04-29 10:47:47'),(15,2,NULL,NULL,NULL,3,'2024-04-29 10:47:00',NULL,NULL,'2024-04-29 10:50:41','2024-04-29 10:50:41'),(17,2,NULL,NULL,NULL,3,'2024-04-29 10:47:00',NULL,NULL,'2024-04-29 10:50:55','2024-04-29 10:50:55'),(70,2,NULL,NULL,NULL,3,'2024-04-29 10:47:00',NULL,NULL,'2024-04-29 11:01:45','2024-04-29 11:01:45'),(71,2,NULL,NULL,NULL,3,'2024-04-29 10:47:00',NULL,NULL,'2024-04-29 11:08:12','2024-04-29 11:08:12'),(72,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-04-29 12:27:01','2024-04-29 12:27:01'),(73,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-04-29 12:27:22','2024-04-29 12:27:22'),(74,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-04-29 12:36:36','2024-04-29 12:36:36'),(76,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-04-29 12:40:11','2024-04-29 12:40:11'),(78,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-04-29 12:42:41','2024-04-29 12:42:41'),(80,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-04-29 12:54:38','2024-04-29 12:54:38'),(81,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-04-29 12:54:51','2024-04-29 12:54:51'),(82,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-04-29 12:55:18','2024-04-29 12:55:18'),(111,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-04-29 13:18:34','2024-04-29 13:18:34'),(113,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-04-30 21:02:04','2024-04-30 21:02:04'),(114,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-04-30 21:09:09','2024-04-30 21:09:09'),(115,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-05-01 00:17:31','2024-05-01 00:17:31'),(116,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-05-01 00:18:56','2024-05-01 00:18:56'),(118,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-05-01 01:05:24','2024-05-01 01:05:24'),(120,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-05-01 10:44:37','2024-05-01 10:44:37'),(121,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-05-01 10:47:46','2024-05-01 10:47:46'),(123,1,NULL,NULL,NULL,2,'2024-04-22 13:03:00',NULL,NULL,'2024-05-01 10:52:14','2024-05-01 10:52:14');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_ztfcongqopnpbwpwmemkhvgjofjmrqkkouum` (`authorId`),
  KEY `idx_wcytlejmldniyeqyixjdeyixlzrstmtsmcgg` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_lfxrjjjndkddkufqxorogcgmjseiebwkysuu` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ohoyqfimmcgtfxrqembwdckvwnixgnceuzmv` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_udtxxfiobpzxttucyexfstyektlpqhmxgqyb` (`fieldLayoutId`),
  KEY `idx_ntlfgkapbjeowuydwqxyjagoqsaujtfjjirt` (`dateDeleted`),
  CONSTRAINT `fk_gtrccdggpxzvviobyjlidkyizwcyerokkkaz` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,1,'homepage','homepage','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-04-22 12:07:39','2024-04-22 13:02:45','2024-04-22 13:02:54','6627b817-a472-4739-8d01-399a8f3ce457'),(2,2,'startpagina','startpagina','house','red',0,'site',NULL,'{{\"Startpagina\"}}',1,'site',NULL,1,'2024-04-22 13:02:09','2024-04-29 12:43:56',NULL,'c55c23ca-6ec1-479c-8438-0f70fce3a3be'),(3,4,'about-content','aboutContent','circle-info','blue',1,'site',NULL,'',1,'site',NULL,1,'2024-04-29 10:47:31','2024-04-29 10:47:31',NULL,'23b3049d-9371-4642-b736-675121176002'),(4,5,'blogposttest','blogposttest','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-04-29 11:16:16','2024-04-29 11:16:16',NULL,'e18eb04b-759e-41cb-a454-42138a30c16d'),(5,6,'Product-Card-Test','productCardTest','album','indigo',1,'site',NULL,'',1,'site',NULL,1,'2024-05-06 12:26:35','2024-05-06 12:26:35',NULL,'bc2570ed-b0f4-4d10-8731-8c5672050ea3');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qudeohyoxtdehlerzrmpubbjbvtvujjkoluy` (`dateDeleted`),
  KEY `idx_sacmvdanxzbenxesnontzvgwlrbpoyfrvtjx` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"b1a3333c-11e1-4a44-8780-c6a7751d3448\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"ab0e7ac1-27bf-4644-b5ed-1c58905eb9b0\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 50, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"a53d9cef-df16-4834-9801-3edf9760bcb2\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"58b4db94-c28e-4425-aa99-3d6acfe2b619\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-22 12:07:39','2024-04-22 13:02:45','2024-04-22 13:02:54','633cf333-82c3-4449-90b6-feaa76acc947'),(2,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"8c29527c-e121-4fbc-b7fa-fefe521b229f\", \"name\": \"Hero Section\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"21010960-2f0a-4e27-b671-5ba471310ff1\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"0cb30b4a-3841-418c-8856-ea680bb04022\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"72d7ee56-dc44-4879-a506-665a7d450161\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Ondertitel\", \"width\": 100, \"handle\": \"pageTitle2\", \"warning\": null, \"fieldUid\": \"beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"6f12157a-e134-4f12-b768-97a5ed2eeed6\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"ca6b0345-14c9-4d36-8a96-ff70fb2cad05\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"58b4db94-c28e-4425-aa99-3d6acfe2b619\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}, {\"uid\": \"4826500a-7311-4bcb-bcac-c30e71418c6c\", \"name\": \"Home - Copy section\", \"elements\": [{\"tip\": null, \"uid\": \"22739534-4086-4c5f-80b4-8dffad3c0937\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": \"pageTitle3\", \"warning\": null, \"fieldUid\": \"beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"17b30490-3b87-4158-a261-8e528b82c667\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"ff53dd1b-b693-4840-93bb-83c470eea8f8\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"822a27b1-5720-4c5a-9848-1e1602fd2cca\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"9e6c42b3-24b7-4f14-aae1-0221bff9b1fe\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-22 13:02:09','2024-05-01 10:47:43',NULL,'073a038a-61a8-45f2-b436-f3beafb8d3d9'),(3,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"c10c681e-e4cd-40c1-b46e-466ccb4eb927\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"493fe1eb-6cbc-45d4-9abe-5347b99b6b21\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-22 13:10:10','2024-04-29 13:09:31',NULL,'9e3338dd-8ac0-4d5e-b278-0d7418c4cc85'),(4,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"a24b665f-4e86-4ccd-bb0e-c3b5aa5451bb\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"8ece0d04-62db-4503-8870-90beb5910e63\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": \"about-title\", \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": \"Add the About-Title here\", \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": \"\", \"uid\": \"37512de1-0223-4d6b-927e-76484a40cef0\", \"type\": \"craft\\\\fieldlayoutelements\\\\Tip\", \"style\": \"warning\", \"dismissible\": false, \"userCondition\": null, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"3eebabbf-1f6a-4de8-8ab5-989268d44106\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"9e6c42b3-24b7-4f14-aae1-0221bff9b1fe\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"c993627b-2d8a-4105-a40d-1d66b4f92164\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"498ef8e8-ab5a-49e8-b3a2-dc96897059e6\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-29 10:47:31','2024-04-29 11:04:22',NULL,'aac08706-2b13-44bf-9d72-540e58f12d54'),(5,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"b55410a1-41e7-4504-b26c-764fa269001f\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"b61b8d9e-035e-43f3-8915-04bbb3ff4b28\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-29 11:16:16','2024-04-29 11:16:16',NULL,'77e5909f-eb7e-4d53-bd76-735061855622'),(6,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"c71a6815-968e-4879-b6b0-20cd267cac8c\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"53820fc2-4b74-4dcb-a5a6-3ac4ef87c8ac\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"7a384d03-3919-4eff-9868-cb5c78d5e020\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"description\", \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"9e6c42b3-24b7-4f14-aae1-0221bff9b1fe\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"ffc805e1-53e8-4ade-9c71-cc53e4c35c0b\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": \"price\", \"warning\": null, \"fieldUid\": \"9e6c42b3-24b7-4f14-aae1-0221bff9b1fe\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"3bb64467-1839-4ed3-8306-3ae541cae36d\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": \"productImage\", \"warning\": null, \"fieldUid\": \"498ef8e8-ab5a-49e8-b3a2-dc96897059e6\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-05-06 12:26:35','2024-05-06 12:26:35',NULL,'ba201ee8-7ac2-44e3-bf04-eadcb5433c23');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_chqjfsjtxwmulxbmftfuhxtisxnyzxmmjibq` (`handle`,`context`),
  KEY `idx_lobcgphromwonkbnjcahdwoluazoiplvsvvy` (`context`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,'Intro','intro','global',NULL,'This is the intro.\r\n-- Add a short introduction text here for this page.',1,'none',NULL,'craft\\fields\\PlainText','{\"uiMode\":\"enlarged\",\"placeholder\":null,\"code\":false,\"multiline\":true,\"initialRows\":4,\"charLimit\":null,\"byteLimit\":null}','2024-04-22 12:13:33','2024-04-22 12:14:49','58b4db94-c28e-4425-aa99-3d6acfe2b619'),(2,'textfield','textfield','global',NULL,'Add body text here.',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":250,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":\"Please add text.\",\"uiMode\":\"normal\"}','2024-04-29 10:53:08','2024-04-29 10:53:08','9e6c42b3-24b7-4f14-aae1-0221bff9b1fe'),(3,'imagetest','imagetest','global',NULL,'Add image here.',0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":true,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7\",\"restrictedLocationSubpath\":null,\"selectionLabel\":\"Add\",\"showCardsInGrid\":false,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-04-29 10:54:53','2024-04-29 12:56:47','498ef8e8-ab5a-49e8-b3a2-dc96897059e6'),(4,'Subtitle','subtitle','global',NULL,'Add the subtitle of the header',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-04-29 12:33:10','2024-04-29 12:33:10','ff53dd1b-b693-4840-93bb-83c470eea8f8'),(5,'Titel','pageTitle','global',NULL,NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"uiMode\":\"normal\",\"placeholder\":null,\"code\":false,\"multiline\":false,\"initialRows\":4,\"charLimit\":null,\"byteLimit\":null}','2024-04-29 12:37:31','2024-04-29 12:38:57','beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed'),(6,'Hero Afbeelding','heroImage','global',NULL,'add the Hero Image here.',1,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":1,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7\",\"restrictedLocationSubpath\":null,\"selectionLabel\":\"Afbeelding toevoegen\",\"showCardsInGrid\":false,\"showSiteMenu\":false,\"showUnpermittedFiles\":true,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-04-29 13:16:40','2024-04-29 13:16:40','ca6b0345-14c9-4d36-8a96-ff70fb2cad05');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_keaebnueoxenernmziyenbulbuokuqyjfmmj` (`name`),
  KEY `idx_ippeufugnbqfzkknsbdmxlvsjtvgjolxseeu` (`handle`),
  KEY `idx_tinglqupyxaukvgmztpdbdjpsyrmnqijbrhn` (`fieldLayoutId`),
  KEY `idx_wiimmbrsgptaalqcnrhhfrtwudetqsnwpnaj` (`sortOrder`),
  CONSTRAINT `fk_ehyyaczfffafmglssiefjhcuzelgqwuodypo` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_naupyrfvxfwhspacatqpsxojbvvqowtgvnlq` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
INSERT INTO `gqlschemas` VALUES (1,'Public Schema','[]',1,'2024-04-22 12:59:52','2024-04-22 12:59:52','9d3c309c-cbb1-484c-aa76-6c735b16d4ab');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tcvwxmximjcqeupdapbebapnyqepdsktufgm` (`accessToken`),
  UNIQUE KEY `idx_iwxjtvbudqeicpplrotekkjgmhibahpvjvcw` (`name`),
  KEY `fk_idujjilpoxlarsdogwguyqdgiazcqbbgbymz` (`schemaId`),
  CONSTRAINT `fk_idujjilpoxlarsdogwguyqdgiazcqbbgbymz` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kkuktcrwahlwyumnjcdcrmcjpbwwqtstuwzt` (`assetId`,`transformString`)
) ENGINE=InnoDB AUTO_INCREMENT=166 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
INSERT INTO `imagetransformindex` VALUES (112,108,'craft\\imagetransforms\\ImageTransformer','aurolink_1.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:42','947aaa96-2769-496f-b600-0d8abc1673c6'),(113,108,'craft\\imagetransforms\\ImageTransformer','aurolink_1.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:42','b9c55553-9861-4b84-b2a2-638c2044627c'),(114,107,'craft\\imagetransforms\\ImageTransformer','aurolink_2.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:42','7a04636a-3b49-4ed5-8998-e1e24322b7fb'),(115,107,'craft\\imagetransforms\\ImageTransformer','aurolink_2.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:42','fe1c65cc-e676-4967-b988-b2c4cfc53d74'),(116,106,'craft\\imagetransforms\\ImageTransformer','aurolink_3.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','8808706d-d73d-4e14-b206-342c9043a1bf'),(117,106,'craft\\imagetransforms\\ImageTransformer','aurolink_3.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','d0f10d68-f0f6-45fe-8396-99c6855f7942'),(118,105,'craft\\imagetransforms\\ImageTransformer','aurolink_4.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','af3a3633-cbc9-4f4f-87fb-2bf38f08b5ba'),(119,105,'craft\\imagetransforms\\ImageTransformer','aurolink_4.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','3d5540bc-7ce7-446b-bbe6-2c3e3cbfaf8f'),(120,104,'craft\\imagetransforms\\ImageTransformer','auroport_1.png',NULL,'_30x29_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','239d298f-efec-40f8-bdd1-1bac9845dc19'),(121,104,'craft\\imagetransforms\\ImageTransformer','auroport_1.png',NULL,'_60x59_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','3e3e07d5-dabf-4471-ad1a-5576bd19aeb9'),(122,103,'craft\\imagetransforms\\ImageTransformer','aurotags_1.png',NULL,'_30x29_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','aaf1ed8f-f0f6-4365-ab6c-7e2fd04e72f3'),(123,103,'craft\\imagetransforms\\ImageTransformer','aurotags_1.png',NULL,'_60x59_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','a1c030fd-68b8-4c70-a157-753126a5a7dd'),(124,102,'craft\\imagetransforms\\ImageTransformer','aurotouch_1.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','e231cc18-0d44-43b0-84d0-7cc8ea8b00b3'),(125,102,'craft\\imagetransforms\\ImageTransformer','aurotouch_1.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','685a68cf-26ad-4324-add4-cdbc91b3080b'),(126,101,'craft\\imagetransforms\\ImageTransformer','aurovision_1.png',NULL,'_30x14_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','03ba9f55-4e6b-4e32-8a40-21f9ac4366fb'),(127,101,'craft\\imagetransforms\\ImageTransformer','aurovision_1.png',NULL,'_60x28_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','fbe47bcc-2602-4148-b5bc-a1800b529b85'),(128,100,'craft\\imagetransforms\\ImageTransformer','aurovision_2.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','c8823894-977e-4976-b9c8-4a368e960aa5'),(129,100,'craft\\imagetransforms\\ImageTransformer','aurovision_2.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','d8600896-2d67-4663-aacf-799df262c7ba'),(130,99,'craft\\imagetransforms\\ImageTransformer','aurovision_3.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','bb8bc4ab-a847-4125-9299-95f9b8e842ef'),(131,99,'craft\\imagetransforms\\ImageTransformer','aurovision_3.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','ae4249f8-575e-49be-b830-abcf19115514'),(132,96,'craft\\imagetransforms\\ImageTransformer','bg_2.png',NULL,'_30x16_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','7305c46e-9d0f-4666-b95e-0c59d424be99'),(133,96,'craft\\imagetransforms\\ImageTransformer','bg_2.png',NULL,'_60x33_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','a8933318-03f5-42a5-860c-4f06ea887c5b'),(134,97,'craft\\imagetransforms\\ImageTransformer','bg_1.png',NULL,'_30x16_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','c0b86290-5f94-425e-ade4-df27e80a0084'),(135,97,'craft\\imagetransforms\\ImageTransformer','bg_1.png',NULL,'_60x33_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','94afb16f-0d68-44d5-9416-2e53be6d5bab'),(136,98,'craft\\imagetransforms\\ImageTransformer','aurowatch_1.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','baa66023-e5aa-4eb2-b611-7116250d63da'),(137,98,'craft\\imagetransforms\\ImageTransformer','aurowatch_1.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','2963028f-1a97-4f73-ba9b-aedd4680298e'),(138,95,'craft\\imagetransforms\\ImageTransformer','pods_1.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','70f5c2d1-5021-4b9c-a2d3-64655d8b053b'),(139,95,'craft\\imagetransforms\\ImageTransformer','pods_1.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','ad231506-531d-438c-b377-f9fd6663855c'),(140,94,'craft\\imagetransforms\\ImageTransformer','pods_2.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','47ad61b6-ed71-43ba-97eb-f671c53f1927'),(141,94,'craft\\imagetransforms\\ImageTransformer','pods_2.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:43','97324f77-186a-4bed-bcee-3b9eb20b5baa'),(142,93,'craft\\imagetransforms\\ImageTransformer','pods_3.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','9cc740cf-e621-4bfd-816a-a2326445dfbe'),(143,93,'craft\\imagetransforms\\ImageTransformer','pods_3.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','6718de83-33c3-47f0-bf4a-97f246f65e79'),(144,92,'craft\\imagetransforms\\ImageTransformer','pods_4.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','cd69c7e4-ca2c-4e4f-aa4f-9a12476b374b'),(145,92,'craft\\imagetransforms\\ImageTransformer','pods_4.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','cbf5bc61-40bc-44ad-9557-9c14c6cfc51d'),(146,91,'craft\\imagetransforms\\ImageTransformer','pods_5.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','98a1e79a-ebc0-4e2c-801b-9b02d0f23f0b'),(147,91,'craft\\imagetransforms\\ImageTransformer','pods_5.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','6ad55c92-4ade-49b2-833f-2fac02ad3833'),(148,90,'craft\\imagetransforms\\ImageTransformer','pods_7.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','a6fecb29-467e-4ac2-b28b-22f0e59d4547'),(149,90,'craft\\imagetransforms\\ImageTransformer','pods_7.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','27be9d53-f477-433c-8c45-e50c346914ad'),(150,89,'craft\\imagetransforms\\ImageTransformer','pods_8.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','a0e5fb81-c246-41ad-9034-697c7af2b158'),(151,89,'craft\\imagetransforms\\ImageTransformer','pods_8.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','535ee731-52fc-44e5-a64a-c44b202dc51b'),(152,88,'craft\\imagetransforms\\ImageTransformer','pods_9.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','adf4d04d-81e6-46ba-aa72-b9a5dc449283'),(153,88,'craft\\imagetransforms\\ImageTransformer','pods_9.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','6642c027-029f-452e-bbb9-9e401e1969dc'),(154,87,'craft\\imagetransforms\\ImageTransformer','pods_case_1.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','f16efdda-53eb-4e52-a8b3-8b896c7f2717'),(155,87,'craft\\imagetransforms\\ImageTransformer','pods_case_1.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','f8e4fda2-4a4e-46f7-ac34-9404b03a98e8'),(156,86,'craft\\imagetransforms\\ImageTransformer','pods_case_2.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','4b1142d1-3510-4902-a9b3-cf62c0486448'),(157,86,'craft\\imagetransforms\\ImageTransformer','pods_case_2.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','c858f707-3a18-41f4-a8d8-177d776d0bcd'),(158,85,'craft\\imagetransforms\\ImageTransformer','pods_case_3.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','c05b1e30-1034-4790-9da3-e4a914a6bdb8'),(159,85,'craft\\imagetransforms\\ImageTransformer','pods_case_3.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','f705f387-e3d0-4252-b5ee-f85815166e76'),(160,84,'craft\\imagetransforms\\ImageTransformer','pods_case_4.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','62f0f503-91cf-4a35-a905-ab38fc3782d6'),(161,84,'craft\\imagetransforms\\ImageTransformer','pods_case_4.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','77f73757-2897-4b0c-bd9b-c91817c24b79'),(162,83,'craft\\imagetransforms\\ImageTransformer','pods_6.png',NULL,'_30x30_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','64eddc85-4f54-410e-8d45-1aca1f79fc85'),(163,83,'craft\\imagetransforms\\ImageTransformer','pods_6.png',NULL,'_60x60_crop_center-center_none',1,0,0,'2024-04-29 13:11:42','2024-04-29 13:11:42','2024-04-29 13:11:44','911df808-a12d-4233-a0bb-ceee9c9c8f08'),(164,108,'craft\\imagetransforms\\ImageTransformer','aurolink_1.png',NULL,'_190x190_crop_center-center_none',1,0,0,'2024-04-29 13:12:09','2024-04-29 13:12:09','2024-04-29 13:12:10','96c756f1-928e-4162-a339-e64a08d01b43'),(165,108,'craft\\imagetransforms\\ImageTransformer','aurolink_1.png',NULL,'_380x380_crop_center-center_none',1,0,0,'2024-04-29 13:12:09','2024-04-29 13:12:09','2024-04-29 13:12:10','cc843e14-7ad6-489a-8ea7-7b0e00614035');
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_licgvoyxjdshztixzqptzkqugcmhcjkjuuze` (`name`),
  KEY `idx_gmbfjfouaowelzmjjinolsofdpjpcodiprqo` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'5.0.4','5.0.0.20',0,'qdufswzlspej','3@fgqqnufzsc','2024-04-22 12:05:28','2024-05-06 12:29:41','95c454ac-0a29-4b88-bf79-a3d73598958c');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mvgwhusfkpvkooltlwxmeftvagvxtzjroczs` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'craft','Install','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','4c5257b5-9b7c-4f34-adc9-6f414a5eaeca'),(2,'craft','m221101_115859_create_entries_authors_table','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','909d9388-aaf1-4908-b7ec-4127142c3332'),(3,'craft','m221107_112121_add_max_authors_to_sections','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','cf7ba3ea-b810-45be-9071-e2d58ee18362'),(4,'craft','m221205_082005_translatable_asset_alt_text','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','a5c9adba-e81e-4d24-bf2a-e6f788bfa173'),(5,'craft','m230314_110309_add_authenticator_table','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','15401ff0-3d81-46f5-9a24-80fcf0b1c08e'),(6,'craft','m230314_111234_add_webauthn_table','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','f7ed063f-226b-4052-a318-5e3d3b4c64e2'),(7,'craft','m230503_120303_add_recoverycodes_table','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','8fa37bb9-64d4-4e43-82b0-17120a42dea5'),(8,'craft','m230511_000000_field_layout_configs','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','4bf06849-ce69-4df1-9204-ec94f7b9e831'),(9,'craft','m230511_215903_content_refactor','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','1453e7c5-5696-4f05-8b25-bb0114256f96'),(10,'craft','m230524_000000_add_entry_type_show_slug_field','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','5d4d7779-1bda-46bd-ad72-514c86deadba'),(11,'craft','m230524_000001_entry_type_icons','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','9fdfb229-6dd7-43d8-bfa6-6b22ff16e414'),(12,'craft','m230524_000002_entry_type_colors','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','ac554fd3-442f-4db5-805f-01ed6335f6d1'),(13,'craft','m230524_220029_global_entry_types','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','d10a518d-eaf5-4231-abb2-5ac3639008a6'),(14,'craft','m230531_123004_add_entry_type_show_status_field','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','d04be4ef-8bb4-4352-bd95-4b77f097fc72'),(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','01a4cc0c-e85d-44d6-ac2a-1558d52d6034'),(16,'craft','m230616_173810_kill_field_groups','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','969ed1da-1c58-4f3c-84cb-a65c433840de'),(17,'craft','m230616_183820_remove_field_name_limit','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','f8ca0a30-f3ac-4b96-9725-033b63036fb6'),(18,'craft','m230617_070415_entrify_matrix_blocks','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','849decc7-ac2a-4ec6-a1b7-400ec8fbe4f4'),(19,'craft','m230710_162700_element_activity','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','06c4e77a-61e3-4632-9bb8-ae71538e9126'),(20,'craft','m230820_162023_fix_cache_id_type','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','d6524111-837c-4c28-bbed-fdaef4191b17'),(21,'craft','m230826_094050_fix_session_id_type','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','1b0eef80-111d-4cd6-9b44-ced5033047d1'),(22,'craft','m230904_190356_address_fields','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','9a15a7b9-d8c9-4d59-9420-e3d3f75eb87a'),(23,'craft','m230928_144045_add_subpath_to_volumes','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','25f2ce4c-e508-4e47-9fcf-f605c1f2bb6b'),(24,'craft','m231013_185640_changedfields_amend_primary_key','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','c61cbb84-97fa-47d3-a170-187b62317caf'),(25,'craft','m231213_030600_element_bulk_ops','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','72cf0edb-1697-4555-b5b9-bf0ec919d9fe'),(26,'craft','m240129_150719_sites_language_amend_length','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','e61d266c-3cf5-4fda-98c6-9262d554c610'),(27,'craft','m240206_035135_convert_json_columns','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','bc3c21f6-f9ea-44e6-b4e6-bc60f6c57a2a'),(28,'craft','m240207_182452_address_line_3','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','9da1ffc0-2d69-4445-bd9a-38c93c8bfd07'),(29,'craft','m240302_212719_solo_preview_targets','2024-04-22 12:05:29','2024-04-22 12:05:29','2024-04-22 12:05:29','7bc6ad26-9bf8-430c-8b94-179f3b02a3fa');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tewsvvnlcmtwjpcksceyhcoczcfllwscqwda` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('dateModified','1714998581'),('email.fromEmail','\"12201074@student.pxl.be\"'),('email.fromName','\"WebExpert-Craft\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.color','\"blue\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elementCondition','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.autocapitalize','true'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.autocomplete','false'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.autocorrect','true'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.class','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.disabled','false'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.elementCondition','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.id','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.includeInCards','false'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.inputType','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.instructions','\"Add the About-Title here\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.label','\"about-title\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.max','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.min','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.name','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.orientation','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.placeholder','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.providesThumbs','false'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.readonly','false'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.requirable','false'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.size','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.step','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.tip','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.title','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.uid','\"8ece0d04-62db-4503-8870-90beb5910e63\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.userCondition','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.warning','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.0.width','100'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.1.dismissible','false'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.1.elementCondition','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.1.style','\"warning\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.1.tip','\"\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\Tip\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.1.uid','\"37512de1-0223-4d6b-927e-76484a40cef0\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.1.userCondition','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.2.elementCondition','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.2.fieldUid','\"9e6c42b3-24b7-4f14-aae1-0221bff9b1fe\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.2.handle','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.2.includeInCards','false'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.2.instructions','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.2.label','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.2.providesThumbs','false'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.2.required','false'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.2.tip','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.2.uid','\"3eebabbf-1f6a-4de8-8ab5-989268d44106\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.2.userCondition','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.2.warning','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.2.width','100'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.3.elementCondition','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.3.fieldUid','\"498ef8e8-ab5a-49e8-b3a2-dc96897059e6\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.3.handle','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.3.includeInCards','false'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.3.instructions','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.3.label','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.3.providesThumbs','false'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.3.required','false'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.3.tip','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.3.uid','\"c993627b-2d8a-4105-a40d-1d66b4f92164\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.3.userCondition','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.3.warning','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.elements.3.width','100'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.name','\"Content\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.uid','\"a24b665f-4e86-4ccd-bb0e-c3b5aa5451bb\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.fieldLayouts.aac08706-2b13-44bf-9d72-540e58f12d54.tabs.0.userCondition','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.handle','\"aboutContent\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.hasTitleField','true'),('entryTypes.23b3049d-9371-4642-b736-675121176002.icon','\"circle-info\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.name','\"about-content\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.showSlugField','true'),('entryTypes.23b3049d-9371-4642-b736-675121176002.showStatusField','true'),('entryTypes.23b3049d-9371-4642-b736-675121176002.slugTranslationKeyFormat','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.slugTranslationMethod','\"site\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.titleFormat','\"\"'),('entryTypes.23b3049d-9371-4642-b736-675121176002.titleTranslationKeyFormat','null'),('entryTypes.23b3049d-9371-4642-b736-675121176002.titleTranslationMethod','\"site\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.color','\"indigo\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elementCondition','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.autocapitalize','true'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.autocomplete','false'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.autocorrect','true'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.class','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.disabled','false'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.elementCondition','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.id','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.includeInCards','false'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.inputType','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.instructions','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.label','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.max','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.min','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.name','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.orientation','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.placeholder','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.providesThumbs','false'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.readonly','false'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.requirable','false'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.size','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.step','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.tip','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.title','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.uid','\"53820fc2-4b74-4dcb-a5a6-3ac4ef87c8ac\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.userCondition','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.warning','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.0.width','100'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.1.elementCondition','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.1.fieldUid','\"9e6c42b3-24b7-4f14-aae1-0221bff9b1fe\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.1.handle','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.1.includeInCards','false'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.1.instructions','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.1.label','\"description\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.1.providesThumbs','false'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.1.required','false'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.1.tip','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.1.uid','\"7a384d03-3919-4eff-9868-cb5c78d5e020\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.1.userCondition','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.1.warning','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.1.width','100'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.2.elementCondition','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.2.fieldUid','\"9e6c42b3-24b7-4f14-aae1-0221bff9b1fe\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.2.handle','\"price\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.2.includeInCards','false'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.2.instructions','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.2.label','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.2.providesThumbs','false'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.2.required','false'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.2.tip','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.2.uid','\"ffc805e1-53e8-4ade-9c71-cc53e4c35c0b\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.2.userCondition','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.2.warning','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.2.width','100'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.3.elementCondition','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.3.fieldUid','\"498ef8e8-ab5a-49e8-b3a2-dc96897059e6\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.3.handle','\"productImage\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.3.includeInCards','false'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.3.instructions','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.3.label','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.3.providesThumbs','false'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.3.required','false'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.3.tip','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.3.uid','\"3bb64467-1839-4ed3-8306-3ae541cae36d\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.3.userCondition','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.3.warning','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.elements.3.width','100'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.name','\"Content\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.uid','\"c71a6815-968e-4879-b6b0-20cd267cac8c\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.fieldLayouts.ba201ee8-7ac2-44e3-bf04-eadcb5433c23.tabs.0.userCondition','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.handle','\"productCardTest\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.hasTitleField','true'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.icon','\"album\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.name','\"Product-Card-Test\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.showSlugField','true'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.showStatusField','true'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.slugTranslationKeyFormat','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.slugTranslationMethod','\"site\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.titleFormat','\"\"'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.titleTranslationKeyFormat','null'),('entryTypes.bc2570ed-b0f4-4d10-8731-8c5672050ea3.titleTranslationMethod','\"site\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.color','\"red\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elementCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.autocapitalize','true'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.autocomplete','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.autocorrect','true'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.class','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.disabled','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.elementCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.id','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.includeInCards','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.inputType','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.instructions','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.label','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.max','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.min','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.name','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.orientation','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.placeholder','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.providesThumbs','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.readonly','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.requirable','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.size','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.step','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.tip','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.title','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.uid','\"21010960-2f0a-4e27-b671-5ba471310ff1\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.userCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.warning','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.0.width','100'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.1.elementCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.1.fieldUid','\"beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.1.handle','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.1.includeInCards','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.1.instructions','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.1.label','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.1.providesThumbs','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.1.required','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.1.tip','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.1.uid','\"0cb30b4a-3841-418c-8856-ea680bb04022\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.1.userCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.1.warning','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.1.width','100'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.2.elementCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.2.fieldUid','\"beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.2.handle','\"pageTitle2\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.2.includeInCards','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.2.instructions','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.2.label','\"Ondertitel\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.2.providesThumbs','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.2.required','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.2.tip','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.2.uid','\"72d7ee56-dc44-4879-a506-665a7d450161\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.2.userCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.2.warning','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.2.width','100'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.3.elementCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.3.fieldUid','\"ca6b0345-14c9-4d36-8a96-ff70fb2cad05\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.3.handle','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.3.includeInCards','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.3.instructions','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.3.label','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.3.providesThumbs','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.3.required','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.3.tip','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.3.uid','\"6f12157a-e134-4f12-b768-97a5ed2eeed6\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.3.userCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.3.warning','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.3.width','100'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.4.elementCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.4.fieldUid','\"58b4db94-c28e-4425-aa99-3d6acfe2b619\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.4.handle','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.4.includeInCards','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.4.instructions','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.4.label','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.4.providesThumbs','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.4.required','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.4.tip','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.4.uid','\"0048490d-ab9d-44b3-bb8e-3dcbbb2c429f\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.4.userCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.4.warning','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.elements.4.width','100'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.name','\"Hero Section\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.uid','\"8c29527c-e121-4fbc-b7fa-fefe521b229f\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.0.userCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elementCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.0.elementCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.0.fieldUid','\"beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.0.handle','\"pageTitle3\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.0.includeInCards','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.0.instructions','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.0.label','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.0.providesThumbs','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.0.required','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.0.tip','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.0.uid','\"22739534-4086-4c5f-80b4-8dffad3c0937\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.0.userCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.0.warning','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.0.width','100'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.1.elementCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.1.fieldUid','\"ff53dd1b-b693-4840-93bb-83c470eea8f8\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.1.handle','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.1.includeInCards','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.1.instructions','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.1.label','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.1.providesThumbs','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.1.required','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.1.tip','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.1.uid','\"17b30490-3b87-4158-a261-8e528b82c667\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.1.userCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.1.warning','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.1.width','100'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.2.elementCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.2.fieldUid','\"9e6c42b3-24b7-4f14-aae1-0221bff9b1fe\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.2.handle','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.2.includeInCards','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.2.instructions','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.2.label','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.2.providesThumbs','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.2.required','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.2.tip','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.2.uid','\"822a27b1-5720-4c5a-9848-1e1602fd2cca\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.2.userCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.2.warning','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.elements.2.width','100'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.name','\"Home - Copy section\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.uid','\"4826500a-7311-4bcb-bcac-c30e71418c6c\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.fieldLayouts.073a038a-61a8-45f2-b436-f3beafb8d3d9.tabs.1.userCondition','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.handle','\"startpagina\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.hasTitleField','false'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.icon','\"house\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.name','\"startpagina\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.showSlugField','true'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.showStatusField','true'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.slugTranslationKeyFormat','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.slugTranslationMethod','\"site\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.titleFormat','\"{{\\\"Startpagina\\\"}}\"'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.titleTranslationKeyFormat','null'),('entryTypes.c55c23ca-6ec1-479c-8438-0f70fce3a3be.titleTranslationMethod','\"site\"'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.color','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elementCondition','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.autocapitalize','true'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.autocomplete','false'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.autocorrect','true'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.class','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.disabled','false'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.elementCondition','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.id','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.includeInCards','false'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.inputType','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.instructions','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.label','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.max','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.min','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.name','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.orientation','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.placeholder','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.providesThumbs','false'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.readonly','false'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.requirable','false'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.size','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.step','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.tip','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.title','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.uid','\"b61b8d9e-035e-43f3-8915-04bbb3ff4b28\"'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.userCondition','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.warning','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.elements.0.width','100'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.name','\"Content\"'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.uid','\"b55410a1-41e7-4504-b26c-764fa269001f\"'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.fieldLayouts.77e5909f-eb7e-4d53-bd76-735061855622.tabs.0.userCondition','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.handle','\"blogposttest\"'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.hasTitleField','true'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.icon','\"\"'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.name','\"blogposttest\"'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.showSlugField','true'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.showStatusField','true'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.slugTranslationKeyFormat','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.slugTranslationMethod','\"site\"'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.titleFormat','\"\"'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.titleTranslationKeyFormat','null'),('entryTypes.e18eb04b-759e-41cb-a454-42138a30c16d.titleTranslationMethod','\"site\"'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.columnSuffix','null'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.handle','\"imagetest\"'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.instructions','\"Add image here.\"'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.name','\"imagetest\"'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.searchable','false'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.allowedKinds','null'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.allowSelfRelations','false'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.allowSubfolders','false'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.allowUploads','true'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.branchLimit','null'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.defaultUploadLocationSource','\"volume:f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7\"'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.defaultUploadLocationSubpath','null'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.localizeRelations','false'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.maintainHierarchy','false'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.maxRelations','1'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.minRelations','null'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.previewMode','\"full\"'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.restrictedDefaultUploadSubpath','null'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.restrictedLocationSource','\"volume:f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7\"'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.restrictedLocationSubpath','null'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.restrictFiles','false'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.restrictLocation','true'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.selectionLabel','\"Add\"'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.showCardsInGrid','false'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.showSiteMenu','true'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.showUnpermittedFiles','false'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.showUnpermittedVolumes','false'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.sources','\"*\"'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.targetSiteId','null'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.validateRelatedElements','false'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.settings.viewMode','\"list\"'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.translationKeyFormat','null'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.translationMethod','\"site\"'),('fields.498ef8e8-ab5a-49e8-b3a2-dc96897059e6.type','\"craft\\\\fields\\\\Assets\"'),('fields.58b4db94-c28e-4425-aa99-3d6acfe2b619.columnSuffix','null'),('fields.58b4db94-c28e-4425-aa99-3d6acfe2b619.handle','\"intro\"'),('fields.58b4db94-c28e-4425-aa99-3d6acfe2b619.instructions','\"This is the intro.\\r\\n-- Add a short introduction text here for this page.\"'),('fields.58b4db94-c28e-4425-aa99-3d6acfe2b619.name','\"Intro\"'),('fields.58b4db94-c28e-4425-aa99-3d6acfe2b619.searchable','true'),('fields.58b4db94-c28e-4425-aa99-3d6acfe2b619.settings.byteLimit','null'),('fields.58b4db94-c28e-4425-aa99-3d6acfe2b619.settings.charLimit','null'),('fields.58b4db94-c28e-4425-aa99-3d6acfe2b619.settings.code','false'),('fields.58b4db94-c28e-4425-aa99-3d6acfe2b619.settings.initialRows','4'),('fields.58b4db94-c28e-4425-aa99-3d6acfe2b619.settings.multiline','true'),('fields.58b4db94-c28e-4425-aa99-3d6acfe2b619.settings.placeholder','null'),('fields.58b4db94-c28e-4425-aa99-3d6acfe2b619.settings.uiMode','\"enlarged\"'),('fields.58b4db94-c28e-4425-aa99-3d6acfe2b619.translationKeyFormat','null'),('fields.58b4db94-c28e-4425-aa99-3d6acfe2b619.translationMethod','\"none\"'),('fields.58b4db94-c28e-4425-aa99-3d6acfe2b619.type','\"craft\\\\fields\\\\PlainText\"'),('fields.9e6c42b3-24b7-4f14-aae1-0221bff9b1fe.columnSuffix','null'),('fields.9e6c42b3-24b7-4f14-aae1-0221bff9b1fe.handle','\"textfield\"'),('fields.9e6c42b3-24b7-4f14-aae1-0221bff9b1fe.instructions','\"Add body text here.\"'),('fields.9e6c42b3-24b7-4f14-aae1-0221bff9b1fe.name','\"textfield\"'),('fields.9e6c42b3-24b7-4f14-aae1-0221bff9b1fe.searchable','false'),('fields.9e6c42b3-24b7-4f14-aae1-0221bff9b1fe.settings.byteLimit','null'),('fields.9e6c42b3-24b7-4f14-aae1-0221bff9b1fe.settings.charLimit','250'),('fields.9e6c42b3-24b7-4f14-aae1-0221bff9b1fe.settings.code','false'),('fields.9e6c42b3-24b7-4f14-aae1-0221bff9b1fe.settings.initialRows','4'),('fields.9e6c42b3-24b7-4f14-aae1-0221bff9b1fe.settings.multiline','false'),('fields.9e6c42b3-24b7-4f14-aae1-0221bff9b1fe.settings.placeholder','\"Please add text.\"'),('fields.9e6c42b3-24b7-4f14-aae1-0221bff9b1fe.settings.uiMode','\"normal\"'),('fields.9e6c42b3-24b7-4f14-aae1-0221bff9b1fe.translationKeyFormat','null'),('fields.9e6c42b3-24b7-4f14-aae1-0221bff9b1fe.translationMethod','\"none\"'),('fields.9e6c42b3-24b7-4f14-aae1-0221bff9b1fe.type','\"craft\\\\fields\\\\PlainText\"'),('fields.beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed.columnSuffix','null'),('fields.beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed.handle','\"pageTitle\"'),('fields.beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed.instructions','null'),('fields.beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed.name','\"Titel\"'),('fields.beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed.searchable','true'),('fields.beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed.settings.byteLimit','null'),('fields.beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed.settings.charLimit','null'),('fields.beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed.settings.code','false'),('fields.beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed.settings.initialRows','4'),('fields.beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed.settings.multiline','false'),('fields.beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed.settings.placeholder','null'),('fields.beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed.settings.uiMode','\"normal\"'),('fields.beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed.translationKeyFormat','null'),('fields.beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed.translationMethod','\"none\"'),('fields.beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed.type','\"craft\\\\fields\\\\PlainText\"'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.columnSuffix','null'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.handle','\"heroImage\"'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.instructions','\"add the Hero Image here.\"'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.name','\"Hero Afbeelding\"'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.searchable','true'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.allowedKinds.0','\"image\"'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.allowSelfRelations','false'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.allowSubfolders','false'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.allowUploads','true'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.branchLimit','null'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.defaultUploadLocationSource','\"volume:f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7\"'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.defaultUploadLocationSubpath','null'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.localizeRelations','false'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.maintainHierarchy','false'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.maxRelations','1'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.minRelations','1'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.previewMode','\"full\"'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.restrictedDefaultUploadSubpath','null'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.restrictedLocationSource','\"volume:f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7\"'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.restrictedLocationSubpath','null'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.restrictFiles','true'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.restrictLocation','false'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.selectionLabel','\"Afbeelding toevoegen\"'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.showCardsInGrid','false'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.showSiteMenu','false'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.showUnpermittedFiles','true'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.showUnpermittedVolumes','false'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.sources','\"*\"'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.targetSiteId','null'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.validateRelatedElements','false'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.settings.viewMode','\"list\"'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.translationKeyFormat','null'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.translationMethod','\"site\"'),('fields.ca6b0345-14c9-4d36-8a96-ff70fb2cad05.type','\"craft\\\\fields\\\\Assets\"'),('fields.ff53dd1b-b693-4840-93bb-83c470eea8f8.columnSuffix','null'),('fields.ff53dd1b-b693-4840-93bb-83c470eea8f8.handle','\"subtitle\"'),('fields.ff53dd1b-b693-4840-93bb-83c470eea8f8.instructions','\"Add the subtitle of the header\"'),('fields.ff53dd1b-b693-4840-93bb-83c470eea8f8.name','\"Subtitle\"'),('fields.ff53dd1b-b693-4840-93bb-83c470eea8f8.searchable','false'),('fields.ff53dd1b-b693-4840-93bb-83c470eea8f8.settings.byteLimit','null'),('fields.ff53dd1b-b693-4840-93bb-83c470eea8f8.settings.charLimit','null'),('fields.ff53dd1b-b693-4840-93bb-83c470eea8f8.settings.code','false'),('fields.ff53dd1b-b693-4840-93bb-83c470eea8f8.settings.initialRows','4'),('fields.ff53dd1b-b693-4840-93bb-83c470eea8f8.settings.multiline','false'),('fields.ff53dd1b-b693-4840-93bb-83c470eea8f8.settings.placeholder','null'),('fields.ff53dd1b-b693-4840-93bb-83c470eea8f8.settings.uiMode','\"normal\"'),('fields.ff53dd1b-b693-4840-93bb-83c470eea8f8.translationKeyFormat','null'),('fields.ff53dd1b-b693-4840-93bb-83c470eea8f8.translationMethod','\"none\"'),('fields.ff53dd1b-b693-4840-93bb-83c470eea8f8.type','\"craft\\\\fields\\\\PlainText\"'),('fs.images.hasUrls','true'),('fs.images.name','\"Afbeeldingen\"'),('fs.images.settings.path','\"@webroot/files\"'),('fs.images.type','\"craft\\\\fs\\\\Local\"'),('fs.images.url','\"/files\"'),('fs.video.hasUrls','true'),('fs.video.name','\"Video\"'),('fs.video.settings.path','\"web/uploads\"'),('fs.video.type','\"craft\\\\fs\\\\Local\"'),('fs.video.url','\"@webroot/uploads\"'),('graphql.schemas.9d3c309c-cbb1-484c-aa76-6c735b16d4ab.isPublic','true'),('graphql.schemas.9d3c309c-cbb1-484c-aa76-6c735b16d4ab.name','\"Public Schema\"'),('meta.__names__.23b3049d-9371-4642-b736-675121176002','\"about-content\"'),('meta.__names__.30150ce9-3e49-4ef5-a72c-62c684180f6e','\"WebExpert-Craft\"'),('meta.__names__.343fae72-1e96-4e99-a047-9a4543e45db2','\"Product-overview\"'),('meta.__names__.498ef8e8-ab5a-49e8-b3a2-dc96897059e6','\"imagetest\"'),('meta.__names__.5194dbae-7b49-4fe0-967a-f57bded8e82f','\"Blog\"'),('meta.__names__.58b4db94-c28e-4425-aa99-3d6acfe2b619','\"Intro\"'),('meta.__names__.69e8880e-4349-4104-8c10-fcf3553ad1ee','\"WebExpert-Craft\"'),('meta.__names__.9d3c309c-cbb1-484c-aa76-6c735b16d4ab','\"Public Schema\"'),('meta.__names__.9e6c42b3-24b7-4f14-aae1-0221bff9b1fe','\"textfield\"'),('meta.__names__.a2cdcb91-aee9-4962-b096-6d0040272d44','\"Homepage\"'),('meta.__names__.b9e04d0e-62af-4434-a28e-0cb9109b2cae','\"about\"'),('meta.__names__.bc2570ed-b0f4-4d10-8731-8c5672050ea3','\"Product-Card-Test\"'),('meta.__names__.beb3fdc0-71d2-47a1-9e92-c6c0a0fd01ed','\"Titel\"'),('meta.__names__.c55c23ca-6ec1-479c-8438-0f70fce3a3be','\"startpagina\"'),('meta.__names__.ca6b0345-14c9-4d36-8a96-ff70fb2cad05','\"Hero Afbeelding\"'),('meta.__names__.e18eb04b-759e-41cb-a454-42138a30c16d','\"blogposttest\"'),('meta.__names__.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7','\"Images\"'),('meta.__names__.ff53dd1b-b693-4840-93bb-83c470eea8f8','\"Subtitle\"'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.defaultPlacement','\"end\"'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.enableVersioning','true'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.entryTypes.0','\"bc2570ed-b0f4-4d10-8731-8c5672050ea3\"'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.handle','\"productOverview\"'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.maxAuthors','1'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.name','\"Product-overview\"'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.propagationMethod','\"all\"'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.siteSettings.30150ce9-3e49-4ef5-a72c-62c684180f6e.enabledByDefault','true'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.siteSettings.30150ce9-3e49-4ef5-a72c-62c684180f6e.hasUrls','true'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.siteSettings.30150ce9-3e49-4ef5-a72c-62c684180f6e.template','\"product-overview/_entry\"'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.siteSettings.30150ce9-3e49-4ef5-a72c-62c684180f6e.uriFormat','\"product-overview/{slug}\"'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.structure.maxLevels','null'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.structure.uid','\"f6da26e7-8b39-4c79-ac5d-a5e37dc0ab20\"'),('sections.343fae72-1e96-4e99-a047-9a4543e45db2.type','\"structure\"'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.defaultPlacement','\"end\"'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.enableVersioning','true'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.entryTypes.0','\"e18eb04b-759e-41cb-a454-42138a30c16d\"'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.handle','\"blog\"'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.maxAuthors','1'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.name','\"Blog\"'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.propagationMethod','\"all\"'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.siteSettings.30150ce9-3e49-4ef5-a72c-62c684180f6e.enabledByDefault','true'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.siteSettings.30150ce9-3e49-4ef5-a72c-62c684180f6e.hasUrls','true'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.siteSettings.30150ce9-3e49-4ef5-a72c-62c684180f6e.template','\"blog/_entry\"'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.siteSettings.30150ce9-3e49-4ef5-a72c-62c684180f6e.uriFormat','\"blog/{slug}\"'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.structure.maxLevels','null'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.structure.uid','\"6778af77-7849-4581-8a63-10512a12c7ad\"'),('sections.5194dbae-7b49-4fe0-967a-f57bded8e82f.type','\"structure\"'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.defaultPlacement','\"end\"'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.enableVersioning','true'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.entryTypes.0','\"c55c23ca-6ec1-479c-8438-0f70fce3a3be\"'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.handle','\"homepage\"'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.maxAuthors','1'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.name','\"Homepage\"'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.propagationMethod','\"all\"'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.siteSettings.30150ce9-3e49-4ef5-a72c-62c684180f6e.enabledByDefault','true'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.siteSettings.30150ce9-3e49-4ef5-a72c-62c684180f6e.hasUrls','true'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.siteSettings.30150ce9-3e49-4ef5-a72c-62c684180f6e.template','\"home-page.twig\"'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.siteSettings.30150ce9-3e49-4ef5-a72c-62c684180f6e.uriFormat','\"__home__\"'),('sections.a2cdcb91-aee9-4962-b096-6d0040272d44.type','\"single\"'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.defaultPlacement','\"end\"'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.enableVersioning','true'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.entryTypes.0','\"23b3049d-9371-4642-b736-675121176002\"'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.handle','\"about\"'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.maxAuthors','1'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.name','\"about\"'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.propagationMethod','\"all\"'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.siteSettings.30150ce9-3e49-4ef5-a72c-62c684180f6e.enabledByDefault','true'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.siteSettings.30150ce9-3e49-4ef5-a72c-62c684180f6e.hasUrls','true'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.siteSettings.30150ce9-3e49-4ef5-a72c-62c684180f6e.template','\"about-page.twig\"'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.siteSettings.30150ce9-3e49-4ef5-a72c-62c684180f6e.uriFormat','\"about\"'),('sections.b9e04d0e-62af-4434-a28e-0cb9109b2cae.type','\"single\"'),('siteGroups.69e8880e-4349-4104-8c10-fcf3553ad1ee.name','\"WebExpert-Craft\"'),('sites.30150ce9-3e49-4ef5-a72c-62c684180f6e.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.30150ce9-3e49-4ef5-a72c-62c684180f6e.handle','\"default\"'),('sites.30150ce9-3e49-4ef5-a72c-62c684180f6e.hasUrls','true'),('sites.30150ce9-3e49-4ef5-a72c-62c684180f6e.language','\"en-US\"'),('sites.30150ce9-3e49-4ef5-a72c-62c684180f6e.name','\"WebExpert-Craft\"'),('sites.30150ce9-3e49-4ef5-a72c-62c684180f6e.primary','true'),('sites.30150ce9-3e49-4ef5-a72c-62c684180f6e.siteGroup','\"69e8880e-4349-4104-8c10-fcf3553ad1ee\"'),('sites.30150ce9-3e49-4ef5-a72c-62c684180f6e.sortOrder','1'),('system.edition','\"team\"'),('system.live','true'),('system.name','\"WebExpert-Craft\"'),('system.retryDuration','null'),('system.schemaVersion','\"5.0.0.20\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.altTranslationKeyFormat','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.altTranslationMethod','\"none\"'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elementCondition','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.autocapitalize','true'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.autocomplete','false'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.autocorrect','true'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.class','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.disabled','false'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.elementCondition','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.id','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.includeInCards','false'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.inputType','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.instructions','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.label','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.max','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.min','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.name','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.orientation','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.placeholder','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.providesThumbs','false'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.readonly','false'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.requirable','false'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.size','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.step','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.tip','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.title','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.uid','\"493fe1eb-6cbc-45d4-9abe-5347b99b6b21\"'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.userCondition','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.warning','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.elements.0.width','100'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.name','\"Content\"'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.uid','\"c10c681e-e4cd-40c1-b46e-466ccb4eb927\"'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fieldLayouts.9e3338dd-8ac0-4d5e-b278-0d7418c4cc85.tabs.0.userCondition','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.fs','\"images\"'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.handle','\"images\"'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.name','\"Images\"'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.sortOrder','1'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.subpath','\"\"'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.titleTranslationKeyFormat','null'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.titleTranslationMethod','\"site\"'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.transformFs','\"\"'),('volumes.f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_wtgrkuamtxsxnuemgkqbpfqgajidrzqtjvjm` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_nzhnguelempxbmspvdotufpdeiqhhvegttmv` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=847 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_snttgdghihaidmvyfyoflxtexwgxdiwtmxjz` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_jawoyssinuozekqewhmfltqfemhsprcsnpqw` (`sourceId`),
  KEY `idx_yhktqzysrpkndvynqppqwjobkhkkkskpfjjb` (`targetId`),
  KEY `idx_isfapnuizglwcuhgccjcntmldwkalhpsqnaz` (`sourceSiteId`),
  CONSTRAINT `fk_dhvfyuksvonpalrenoqluldoglpmbwasupos` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qnfhvyqioqcagzjedvipnufiznclstchpukv` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uvbhzobhjffiksjvyzfbqdbcdoabqnkigmqz` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
INSERT INTO `relations` VALUES (3,3,80,NULL,31,1,'2024-04-29 12:54:38','2024-04-29 12:54:38','faa79429-cb53-4410-99d0-263d125e671d'),(4,3,81,NULL,31,1,'2024-04-29 12:54:51','2024-04-29 12:54:51','52b137cf-cc4e-4fa3-bdc7-743c90201851'),(5,3,82,NULL,31,1,'2024-04-29 12:55:18','2024-04-29 12:55:18','2d09bbed-0f91-4442-8d07-8ef7641c0e56'),(7,6,6,NULL,96,1,'2024-04-29 13:18:34','2024-04-29 13:18:34','46d0bcf5-4322-4dca-bf18-6940fec470ca'),(8,6,111,NULL,96,1,'2024-04-29 13:18:34','2024-04-29 13:18:34','d69ddc10-6b1c-471b-aa1f-13efe7bf3594'),(10,6,113,NULL,96,1,'2024-04-30 21:02:04','2024-04-30 21:02:04','c6d13ace-8cc1-43e3-8066-8378f5ea7cb1'),(11,6,114,NULL,96,1,'2024-04-30 21:09:09','2024-04-30 21:09:09','f038306b-c99c-4a2a-a9eb-c75e32aee366'),(12,6,115,NULL,96,1,'2024-05-01 00:17:31','2024-05-01 00:17:31','f41d7958-0cb4-41bc-957f-28170c017ec8'),(13,6,116,NULL,96,1,'2024-05-01 00:18:56','2024-05-01 00:18:56','0e57d531-311f-4c7c-8634-94279610c795'),(15,6,118,NULL,96,1,'2024-05-01 01:05:24','2024-05-01 01:05:24','ca9f50f0-deed-4d05-bc51-1c5285b10c79'),(17,6,120,NULL,96,1,'2024-05-01 10:44:37','2024-05-01 10:44:37','b8ffd305-798a-4064-94e8-ab5372ed8abe'),(18,6,121,NULL,96,1,'2024-05-01 10:47:46','2024-05-01 10:47:46','3b3de510-dad3-40b6-83b2-bf57b7682904'),(20,6,123,NULL,96,1,'2024-05-01 10:52:14','2024-05-01 10:52:14','07abb52c-13e3-43b9-b438-2d40ebeeed1c');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('26f510a','@craft/web/assets/authmethodsetup/dist'),('2a04e257','@craft/web/assets/vue/dist'),('2a5c1208','@craft/web/assets/editsection/dist'),('3121b5e5','@craft/web/assets/feed/dist'),('3138759d','@craft/web/assets/clearcaches/dist'),('31873f1b','@craft/web/assets/assetindexes/dist'),('3bb338bb','@craft/web/assets/jquerypayment/dist'),('3be0e7d9','@craft/web/assets/jquerytouchevents/dist'),('3e243a0c','@craft/web/assets/velocity/dist'),('4862932e','@craft/web/assets/dashboard/dist'),('4a3afad','@craft/web/assets/dbbackup/dist'),('5be8178c','@craft/web/assets/routes/dist'),('5cb411a1','@craft/web/assets/htmx/dist'),('67fa0365','@craft/web/assets/jqueryui/dist'),('68fd8c9b','@craft/web/assets/elementresizedetector/dist'),('6d1d9373','@bower/jquery/dist'),('71b3cc78','@craft/web/assets/updates/dist'),('7209f6a7','@craft/web/assets/prismjs/dist'),('7981d5ce','@craft/web/assets/fileupload/dist'),('7e8e265','@craft/web/assets/picturefill/dist'),('89a12d9','@craft/web/assets/timepicker/dist'),('8fd7a99f','@craft/web/assets/axios/dist'),('94a55492','@craft/web/assets/conditionbuilder/dist'),('97223cc6','@craft/web/assets/recententries/dist'),('9a60c3ee','@craft/web/assets/findreplace/dist'),('a0b72af3','@craft/web/assets/generalsettings/dist'),('a2b288c7','@craft/web/assets/iframeresizer/dist'),('a4db5df1','@craft/web/assets/fieldsettings/dist'),('a9987ea8','@craft/web/assets/updateswidget/dist'),('a9d38170','@craft/web/assets/d3/dist'),('b3e6a739','@craft/web/assets/cp/dist'),('b8bbbf53','@craft/web/assets/tailwindreset/dist'),('ba9d9744','@craft/web/assets/pluginstore/dist'),('bfae0571','@craft/web/assets/selectize/dist'),('c0027d25','@craft/web/assets/admintable/dist'),('c505f65','@craft/web/assets/xregexp/dist'),('c5bb0361','@craft/web/assets/focalpoint/dist'),('c9a09de9','@craft/web/assets/passkeysetup/dist'),('d18c3eda','@craft/web/assets/garnish/dist'),('e3488a1','@craft/web/assets/craftsupport/dist'),('e9149ff3','@craft/web/assets/utilities/dist'),('eb7b49b9','@craft/web/assets/userpermissions/dist'),('eef765d3','@craft/web/assets/queuemanager/dist'),('f7cc0dd0','@craft/web/assets/sites/dist'),('f93e09cd','@craft/web/assets/fabric/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lhlzlzsitdxygagtuijrcxgendglgcmhcron` (`canonicalId`,`num`),
  KEY `fk_epovheblbkzreweohwuangfnmaxuqjpadgpx` (`creatorId`),
  CONSTRAINT `fk_epovheblbkzreweohwuangfnmaxuqjpadgpx` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ulzzkywjlvanfuremvbwjdjbnclwohtogslr` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,2,1,1,NULL),(2,2,1,2,NULL),(3,2,1,3,NULL),(4,6,1,1,NULL),(5,6,1,2,NULL),(6,6,1,3,'Applied “Draft 1”'),(7,6,1,4,''),(8,12,1,1,NULL),(9,12,1,2,'Applied “Draft 1”'),(10,12,1,3,'Applied “Draft 1”'),(11,12,1,4,NULL),(12,12,1,5,NULL),(13,6,1,5,NULL),(14,6,1,6,NULL),(15,6,1,7,NULL),(16,6,1,8,'Applied “Draft 1”'),(17,6,1,9,'Applied “Draft 1”'),(18,6,1,10,'Applied “Draft 1”'),(19,6,1,11,''),(20,6,1,12,''),(21,6,1,13,'Applied “Draft 1”'),(22,6,1,14,'Applied “Draft 1”'),(23,6,1,15,''),(24,6,1,16,NULL),(25,6,1,17,NULL),(26,6,1,18,'Applied “Draft 1”'),(27,6,1,19,'Applied “Draft 1”'),(28,6,1,20,NULL),(29,6,1,21,'Applied “Draft 1”');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_ioejwzvpnxcsvwltzujnplxbmsynrbandwfy` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' 12201074 student pxl be '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' janhuysmans '),(2,'slug',0,1,' startpagina '),(2,'title',0,1,' startpagina '),(6,'field',1,1,' test intro we deliver clarity silence a bridge between the rhythms of modernity and the timeless grace of a bygone age let auro become an extension of you enriching life and proving that in the midst of the cacophony music could be a sanctuary and innovation could be a timeless marvel '),(6,'field',5,1,' find your vibe youve never felt like this before feel the future '),(6,'field',6,1,' bg 2 '),(6,'slug',0,1,' homepage '),(6,'title',0,1,' startpagina '),(12,'slug',0,1,' about '),(12,'title',0,1,' over ons '),(18,'alt',0,1,''),(18,'extension',0,1,' png '),(18,'filename',0,1,' pods case 4 png '),(18,'kind',0,1,' image '),(18,'slug',0,1,''),(18,'title',0,1,' pods case 4 '),(19,'alt',0,1,''),(19,'extension',0,1,' png '),(19,'filename',0,1,' pods case 3 png '),(19,'kind',0,1,' image '),(19,'slug',0,1,''),(19,'title',0,1,' pods case 3 '),(20,'alt',0,1,''),(20,'extension',0,1,' png '),(20,'filename',0,1,' pods case 2 png '),(20,'kind',0,1,' image '),(20,'slug',0,1,''),(20,'title',0,1,' pods case 2 '),(21,'alt',0,1,''),(21,'extension',0,1,' png '),(21,'filename',0,1,' pods case 1 png '),(21,'kind',0,1,' image '),(21,'slug',0,1,''),(21,'title',0,1,' pods case 1 '),(22,'alt',0,1,''),(22,'extension',0,1,' png '),(22,'filename',0,1,' pods 9 png '),(22,'kind',0,1,' image '),(22,'slug',0,1,''),(22,'title',0,1,' pods 9 '),(23,'alt',0,1,''),(23,'extension',0,1,' png '),(23,'filename',0,1,' pods 8 png '),(23,'kind',0,1,' image '),(23,'slug',0,1,''),(23,'title',0,1,' pods 8 '),(24,'alt',0,1,''),(24,'extension',0,1,' png '),(24,'filename',0,1,' pods 7 png '),(24,'kind',0,1,' image '),(24,'slug',0,1,''),(24,'title',0,1,' pods 7 '),(25,'alt',0,1,''),(25,'extension',0,1,' png '),(25,'filename',0,1,' pods 6 png '),(25,'kind',0,1,' image '),(25,'slug',0,1,''),(25,'title',0,1,' pods 6 '),(26,'alt',0,1,''),(26,'extension',0,1,' png '),(26,'filename',0,1,' pods 5 png '),(26,'kind',0,1,' image '),(26,'slug',0,1,''),(26,'title',0,1,' pods 5 '),(27,'alt',0,1,''),(27,'extension',0,1,' png '),(27,'filename',0,1,' pods 4 png '),(27,'kind',0,1,' image '),(27,'slug',0,1,''),(27,'title',0,1,' pods 4 '),(28,'alt',0,1,''),(28,'extension',0,1,' png '),(28,'filename',0,1,' pods 3 png '),(28,'kind',0,1,' image '),(28,'slug',0,1,''),(28,'title',0,1,' pods 3 '),(29,'alt',0,1,''),(29,'extension',0,1,' png '),(29,'filename',0,1,' pods 2 png '),(29,'kind',0,1,' image '),(29,'slug',0,1,''),(29,'title',0,1,' pods 2 '),(30,'alt',0,1,''),(30,'extension',0,1,' png '),(30,'filename',0,1,' pods 1 png '),(30,'kind',0,1,' image '),(30,'slug',0,1,''),(30,'title',0,1,' pods 1 '),(31,'alt',0,1,''),(31,'extension',0,1,' png '),(31,'filename',0,1,' bg 2 png '),(31,'kind',0,1,' image '),(31,'slug',0,1,''),(31,'title',0,1,' bg 2 '),(32,'alt',0,1,''),(32,'extension',0,1,' png '),(32,'filename',0,1,' bg 1 png '),(32,'kind',0,1,' image '),(32,'slug',0,1,''),(32,'title',0,1,' bg 1 '),(33,'alt',0,1,''),(33,'extension',0,1,' png '),(33,'filename',0,1,' aurowatch 1 png '),(33,'kind',0,1,' image '),(33,'slug',0,1,''),(33,'title',0,1,' aurowatch 1 '),(34,'alt',0,1,''),(34,'extension',0,1,' png '),(34,'filename',0,1,' aurovision 3 png '),(34,'kind',0,1,' image '),(34,'slug',0,1,''),(34,'title',0,1,' aurovision 3 '),(35,'alt',0,1,''),(35,'extension',0,1,' png '),(35,'filename',0,1,' aurovision 2 png '),(35,'kind',0,1,' image '),(35,'slug',0,1,''),(35,'title',0,1,' aurovision 2 '),(36,'alt',0,1,''),(36,'extension',0,1,' png '),(36,'filename',0,1,' aurovision 1 png '),(36,'kind',0,1,' image '),(36,'slug',0,1,''),(36,'title',0,1,' aurovision 1 '),(37,'alt',0,1,''),(37,'extension',0,1,' png '),(37,'filename',0,1,' aurotouch 1 png '),(37,'kind',0,1,' image '),(37,'slug',0,1,''),(37,'title',0,1,' aurotouch 1 '),(38,'alt',0,1,''),(38,'extension',0,1,' png '),(38,'filename',0,1,' aurotags 1 png '),(38,'kind',0,1,' image '),(38,'slug',0,1,''),(38,'title',0,1,' aurotags 1 '),(39,'alt',0,1,''),(39,'extension',0,1,' png '),(39,'filename',0,1,' auroport 1 png '),(39,'kind',0,1,' image '),(39,'slug',0,1,''),(39,'title',0,1,' auroport 1 '),(40,'alt',0,1,''),(40,'extension',0,1,' png '),(40,'filename',0,1,' aurolink 4 png '),(40,'kind',0,1,' image '),(40,'slug',0,1,''),(40,'title',0,1,' aurolink 4 '),(41,'alt',0,1,''),(41,'extension',0,1,' png '),(41,'filename',0,1,' aurolink 3 png '),(41,'kind',0,1,' image '),(41,'slug',0,1,''),(41,'title',0,1,' aurolink 3 '),(42,'alt',0,1,''),(42,'extension',0,1,' png '),(42,'filename',0,1,' aurolink 2 png '),(42,'kind',0,1,' image '),(42,'slug',0,1,''),(42,'title',0,1,' aurolink 2 '),(43,'alt',0,1,''),(43,'extension',0,1,' png '),(43,'filename',0,1,' aurolink 1 png '),(43,'kind',0,1,' image '),(43,'slug',0,1,''),(43,'title',0,1,' aurolink 1 '),(44,'alt',0,1,''),(44,'extension',0,1,' png '),(44,'filename',0,1,' pods case 4 2024 04 29 105853 xkab png '),(44,'kind',0,1,' image '),(44,'slug',0,1,''),(44,'title',0,1,' pods case 4 '),(45,'alt',0,1,''),(45,'extension',0,1,' png '),(45,'filename',0,1,' pods case 3 2024 04 29 105853 slrz png '),(45,'kind',0,1,' image '),(45,'slug',0,1,''),(45,'title',0,1,' pods case 3 '),(46,'alt',0,1,''),(46,'extension',0,1,' png '),(46,'filename',0,1,' pods case 2 2024 04 29 105854 iafq png '),(46,'kind',0,1,' image '),(46,'slug',0,1,''),(46,'title',0,1,' pods case 2 '),(47,'alt',0,1,''),(47,'extension',0,1,' png '),(47,'filename',0,1,' pods case 1 2024 04 29 105854 fipp png '),(47,'kind',0,1,' image '),(47,'slug',0,1,''),(47,'title',0,1,' pods case 1 '),(48,'alt',0,1,''),(48,'extension',0,1,' png '),(48,'filename',0,1,' pods 9 2024 04 29 105854 yyxa png '),(48,'kind',0,1,' image '),(48,'slug',0,1,''),(48,'title',0,1,' pods 9 '),(49,'alt',0,1,''),(49,'extension',0,1,' png '),(49,'filename',0,1,' pods 8 2024 04 29 105855 yjyr png '),(49,'kind',0,1,' image '),(49,'slug',0,1,''),(49,'title',0,1,' pods 8 '),(50,'alt',0,1,''),(50,'extension',0,1,' png '),(50,'filename',0,1,' pods 7 2024 04 29 105855 xwhs png '),(50,'kind',0,1,' image '),(50,'slug',0,1,''),(50,'title',0,1,' pods 7 '),(51,'alt',0,1,''),(51,'extension',0,1,' png '),(51,'filename',0,1,' pods 6 2024 04 29 105855 smwn png '),(51,'kind',0,1,' image '),(51,'slug',0,1,''),(51,'title',0,1,' pods 6 '),(52,'alt',0,1,''),(52,'extension',0,1,' png '),(52,'filename',0,1,' pods 5 2024 04 29 105856 lpie png '),(52,'kind',0,1,' image '),(52,'slug',0,1,''),(52,'title',0,1,' pods 5 '),(53,'alt',0,1,''),(53,'extension',0,1,' png '),(53,'filename',0,1,' pods 4 2024 04 29 105856 vhhp png '),(53,'kind',0,1,' image '),(53,'slug',0,1,''),(53,'title',0,1,' pods 4 '),(54,'alt',0,1,''),(54,'extension',0,1,' png '),(54,'filename',0,1,' pods 3 2024 04 29 105856 spkn png '),(54,'kind',0,1,' image '),(54,'slug',0,1,''),(54,'title',0,1,' pods 3 '),(55,'alt',0,1,''),(55,'extension',0,1,' png '),(55,'filename',0,1,' pods 2 2024 04 29 105856 wuvw png '),(55,'kind',0,1,' image '),(55,'slug',0,1,''),(55,'title',0,1,' pods 2 '),(56,'alt',0,1,''),(56,'extension',0,1,' png '),(56,'filename',0,1,' pods 1 2024 04 29 105857 uzis png '),(56,'kind',0,1,' image '),(56,'slug',0,1,''),(56,'title',0,1,' pods 1 '),(57,'alt',0,1,''),(57,'extension',0,1,' png '),(57,'filename',0,1,' bg 2 2024 04 29 105857 bhqn png '),(57,'kind',0,1,' image '),(57,'slug',0,1,''),(57,'title',0,1,' bg 2 '),(58,'alt',0,1,''),(58,'extension',0,1,' png '),(58,'filename',0,1,' bg 1 2024 04 29 105857 zfwq png '),(58,'kind',0,1,' image '),(58,'slug',0,1,''),(58,'title',0,1,' bg 1 '),(59,'alt',0,1,''),(59,'extension',0,1,' png '),(59,'filename',0,1,' aurowatch 1 2024 04 29 105858 unjr png '),(59,'kind',0,1,' image '),(59,'slug',0,1,''),(59,'title',0,1,' aurowatch 1 '),(60,'alt',0,1,''),(60,'extension',0,1,' png '),(60,'filename',0,1,' aurovision 3 2024 04 29 105858 whml png '),(60,'kind',0,1,' image '),(60,'slug',0,1,''),(60,'title',0,1,' aurovision 3 '),(61,'alt',0,1,''),(61,'extension',0,1,' png '),(61,'filename',0,1,' aurovision 2 2024 04 29 105859 beum png '),(61,'kind',0,1,' image '),(61,'slug',0,1,''),(61,'title',0,1,' aurovision 2 '),(62,'alt',0,1,''),(62,'extension',0,1,' png '),(62,'filename',0,1,' aurovision 1 2024 04 29 105859 lwrl png '),(62,'kind',0,1,' image '),(62,'slug',0,1,''),(62,'title',0,1,' aurovision 1 '),(63,'alt',0,1,''),(63,'extension',0,1,' png '),(63,'filename',0,1,' aurotouch 1 2024 04 29 105900 kohl png '),(63,'kind',0,1,' image '),(63,'slug',0,1,''),(63,'title',0,1,' aurotouch 1 '),(64,'alt',0,1,''),(64,'extension',0,1,' png '),(64,'filename',0,1,' aurotags 1 2024 04 29 105900 nmgn png '),(64,'kind',0,1,' image '),(64,'slug',0,1,''),(64,'title',0,1,' aurotags 1 '),(65,'alt',0,1,''),(65,'extension',0,1,' png '),(65,'filename',0,1,' auroport 1 2024 04 29 105901 utrt png '),(65,'kind',0,1,' image '),(65,'slug',0,1,''),(65,'title',0,1,' auroport 1 '),(66,'alt',0,1,''),(66,'extension',0,1,' png '),(66,'filename',0,1,' aurolink 4 2024 04 29 105901 qudu png '),(66,'kind',0,1,' image '),(66,'slug',0,1,''),(66,'title',0,1,' aurolink 4 '),(67,'alt',0,1,''),(67,'extension',0,1,' png '),(67,'filename',0,1,' aurolink 3 2024 04 29 105901 rtgz png '),(67,'kind',0,1,' image '),(67,'slug',0,1,''),(67,'title',0,1,' aurolink 3 '),(68,'alt',0,1,''),(68,'extension',0,1,' png '),(68,'filename',0,1,' aurolink 2 2024 04 29 105902 oxeu png '),(68,'kind',0,1,' image '),(68,'slug',0,1,''),(68,'title',0,1,' aurolink 2 '),(69,'alt',0,1,''),(69,'extension',0,1,' png '),(69,'filename',0,1,' aurolink 1 2024 04 29 105902 qzul png '),(69,'kind',0,1,' image '),(69,'slug',0,1,''),(69,'title',0,1,' aurolink 1 '),(83,'alt',0,1,''),(83,'extension',0,1,' png '),(83,'filename',0,1,' pods 6 png '),(83,'kind',0,1,' image '),(83,'slug',0,1,''),(83,'title',0,1,' pods 6 '),(84,'alt',0,1,''),(84,'extension',0,1,' png '),(84,'filename',0,1,' pods case 4 png '),(84,'kind',0,1,' image '),(84,'slug',0,1,''),(84,'title',0,1,' pods case 4 '),(85,'alt',0,1,''),(85,'extension',0,1,' png '),(85,'filename',0,1,' pods case 3 png '),(85,'kind',0,1,' image '),(85,'slug',0,1,''),(85,'title',0,1,' pods case 3 '),(86,'alt',0,1,''),(86,'extension',0,1,' png '),(86,'filename',0,1,' pods case 2 png '),(86,'kind',0,1,' image '),(86,'slug',0,1,''),(86,'title',0,1,' pods case 2 '),(87,'alt',0,1,''),(87,'extension',0,1,' png '),(87,'filename',0,1,' pods case 1 png '),(87,'kind',0,1,' image '),(87,'slug',0,1,''),(87,'title',0,1,' pods case 1 '),(88,'alt',0,1,''),(88,'extension',0,1,' png '),(88,'filename',0,1,' pods 9 png '),(88,'kind',0,1,' image '),(88,'slug',0,1,''),(88,'title',0,1,' pods 9 '),(89,'alt',0,1,''),(89,'extension',0,1,' png '),(89,'filename',0,1,' pods 8 png '),(89,'kind',0,1,' image '),(89,'slug',0,1,''),(89,'title',0,1,' pods 8 '),(90,'alt',0,1,''),(90,'extension',0,1,' png '),(90,'filename',0,1,' pods 7 png '),(90,'kind',0,1,' image '),(90,'slug',0,1,''),(90,'title',0,1,' pods 7 '),(91,'alt',0,1,''),(91,'extension',0,1,' png '),(91,'filename',0,1,' pods 5 png '),(91,'kind',0,1,' image '),(91,'slug',0,1,''),(91,'title',0,1,' pods 5 '),(92,'alt',0,1,''),(92,'extension',0,1,' png '),(92,'filename',0,1,' pods 4 png '),(92,'kind',0,1,' image '),(92,'slug',0,1,''),(92,'title',0,1,' pods 4 '),(93,'alt',0,1,''),(93,'extension',0,1,' png '),(93,'filename',0,1,' pods 3 png '),(93,'kind',0,1,' image '),(93,'slug',0,1,''),(93,'title',0,1,' pods 3 '),(94,'alt',0,1,''),(94,'extension',0,1,' png '),(94,'filename',0,1,' pods 2 png '),(94,'kind',0,1,' image '),(94,'slug',0,1,''),(94,'title',0,1,' pods 2 '),(95,'alt',0,1,''),(95,'extension',0,1,' png '),(95,'filename',0,1,' pods 1 png '),(95,'kind',0,1,' image '),(95,'slug',0,1,''),(95,'title',0,1,' pods 1 '),(96,'alt',0,1,''),(96,'extension',0,1,' png '),(96,'filename',0,1,' bg 2 png '),(96,'kind',0,1,' image '),(96,'slug',0,1,''),(96,'title',0,1,' bg 2 '),(97,'alt',0,1,''),(97,'extension',0,1,' png '),(97,'filename',0,1,' bg 1 png '),(97,'kind',0,1,' image '),(97,'slug',0,1,''),(97,'title',0,1,' bg 1 '),(98,'alt',0,1,''),(98,'extension',0,1,' png '),(98,'filename',0,1,' aurowatch 1 png '),(98,'kind',0,1,' image '),(98,'slug',0,1,''),(98,'title',0,1,' aurowatch 1 '),(99,'alt',0,1,''),(99,'extension',0,1,' png '),(99,'filename',0,1,' aurovision 3 png '),(99,'kind',0,1,' image '),(99,'slug',0,1,''),(99,'title',0,1,' aurovision 3 '),(100,'alt',0,1,''),(100,'extension',0,1,' png '),(100,'filename',0,1,' aurovision 2 png '),(100,'kind',0,1,' image '),(100,'slug',0,1,''),(100,'title',0,1,' aurovision 2 '),(101,'alt',0,1,''),(101,'extension',0,1,' png '),(101,'filename',0,1,' aurovision 1 png '),(101,'kind',0,1,' image '),(101,'slug',0,1,''),(101,'title',0,1,' aurovision 1 '),(102,'alt',0,1,''),(102,'extension',0,1,' png '),(102,'filename',0,1,' aurotouch 1 png '),(102,'kind',0,1,' image '),(102,'slug',0,1,''),(102,'title',0,1,' aurotouch 1 '),(103,'alt',0,1,''),(103,'extension',0,1,' png '),(103,'filename',0,1,' aurotags 1 png '),(103,'kind',0,1,' image '),(103,'slug',0,1,''),(103,'title',0,1,' aurotags 1 '),(104,'alt',0,1,''),(104,'extension',0,1,' png '),(104,'filename',0,1,' auroport 1 png '),(104,'kind',0,1,' image '),(104,'slug',0,1,''),(104,'title',0,1,' auroport 1 '),(105,'alt',0,1,''),(105,'extension',0,1,' png '),(105,'filename',0,1,' aurolink 4 png '),(105,'kind',0,1,' image '),(105,'slug',0,1,''),(105,'title',0,1,' aurolink 4 '),(106,'alt',0,1,''),(106,'extension',0,1,' png '),(106,'filename',0,1,' aurolink 3 png '),(106,'kind',0,1,' image '),(106,'slug',0,1,''),(106,'title',0,1,' aurolink 3 '),(107,'alt',0,1,''),(107,'extension',0,1,' png '),(107,'filename',0,1,' aurolink 2 png '),(107,'kind',0,1,' image '),(107,'slug',0,1,''),(107,'title',0,1,' aurolink 2 '),(108,'alt',0,1,''),(108,'extension',0,1,' png '),(108,'filename',0,1,' aurolink 1 png '),(108,'kind',0,1,' image '),(108,'slug',0,1,''),(108,'title',0,1,' aurolink 1 '),(109,'alt',0,1,''),(109,'extension',0,1,' mp4 '),(109,'filename',0,1,' auro vid1 mp4 '),(109,'kind',0,1,' video '),(109,'slug',0,1,''),(109,'title',0,1,' auro vid1 '),(124,'alt',0,1,''),(124,'extension',0,1,' mp4 '),(124,'filename',0,1,' auro vid1 mp4 '),(124,'kind',0,1,' video '),(124,'slug',0,1,''),(124,'title',0,1,' auro vid1 ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yvobstbunurvrsjoqrjistybzjvrdikeoxzo` (`handle`),
  KEY `idx_sgjzoyxjalyygezmjycgidnbpkszwinutrln` (`name`),
  KEY `idx_rhklmznsrcrubfeqpwccyyhnagzzheelsjgt` (`structureId`),
  KEY `idx_wsrsigqqcfululptijjmbiwmomwelndqlsll` (`dateDeleted`),
  CONSTRAINT `fk_osyoawiclwkvxxairksqqzwcuumeiqogvyvk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'Homepage','homepage','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-04-22 12:07:43','2024-04-22 13:07:43',NULL,'a2cdcb91-aee9-4962-b096-6d0040272d44'),(2,NULL,'about','about','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-04-29 10:47:47','2024-04-29 10:47:47',NULL,'b9e04d0e-62af-4434-a28e-0cb9109b2cae'),(3,1,'Blog','blog','structure',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-04-29 11:16:19','2024-04-29 12:22:57',NULL,'5194dbae-7b49-4fe0-967a-f57bded8e82f'),(4,2,'Product-overview','productOverview','structure',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-05-06 12:26:47','2024-05-06 12:29:41',NULL,'343fae72-1e96-4e99-a047-9a4543e45db2');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_ompkecrgfklbmgevywlxsukjmashfyhdtqss` (`typeId`),
  CONSTRAINT `fk_ompkecrgfklbmgevywlxsukjmashfyhdtqss` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ygeswgxrdjoncjngcvsqjbgidkhjmxcjfroh` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
INSERT INTO `sections_entrytypes` VALUES (1,2,1),(2,3,1),(3,4,1),(4,5,1);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ewuofyebzpqtqdkwvienwprmrhyjklgqphxg` (`sectionId`,`siteId`),
  KEY `idx_gsfacgjootzjtrasdqhuloirzcjngmliajza` (`siteId`),
  CONSTRAINT `fk_eikzfaiascwniztobegdqrekvkwtnvtlmnxo` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jytubzqchmhhowstvphwdmtkcvgevydaacjl` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'__home__','home-page.twig',1,'2024-04-22 12:07:43','2024-05-01 00:18:56','a49999ae-8cbf-4a32-80db-561ef7b800b9'),(2,2,1,1,'about','about-page.twig',1,'2024-04-29 10:47:47','2024-04-29 10:47:47','f3aa3925-a85c-47d0-afae-875fc3c816e8'),(3,3,1,1,'blog/{slug}','blog/_entry',1,'2024-04-29 11:16:19','2024-04-29 11:16:19','f1c0793b-6be5-4d62-b935-e702caed4687'),(4,4,1,1,'product-overview/{slug}','product-overview/_entry',1,'2024-05-06 12:26:47','2024-05-06 12:26:47','4e314d2e-87ec-4920-9e76-5c6a6841dd39');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ibbqywwihqdcqagfgsqvhdpghzqrzmwmtsay` (`uid`),
  KEY `idx_umaajimzvgktkibbppdltrrtbottscvtvxne` (`token`),
  KEY `idx_fjditbtdvfpcqcdueivwrluvylcmvsmhadqt` (`dateUpdated`),
  KEY `idx_tgllutpxqpzpsqpuiayfurkxgtytkslrscoh` (`userId`),
  CONSTRAINT `fk_yfjmlmozbclpldurqerkdlmpdfrnpuqbnnrp` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,1,'mzPUxyncQBJq_Ca8PDUrxI8xu2ZTIpQDnBC4y-X2Ru4vX3FZusgqWkPUm8oGDCgeOHfsI_O_b1NLfuioRBeTt7dc39YUSo76q8iV','2024-04-22 12:05:29','2024-04-22 13:59:39','708bd2df-af8d-4e33-972e-640e6b9add2b'),(2,1,'2ZwphfD87vGaSUek17050AnjhO5JeDGyFPi6LZNuPMoBDBoEIZZgqRqM-oRB5dFXqp0KgOgTaAckuqawlcsvjwc-c57gC_sGK7O7','2024-04-29 10:18:01','2024-04-29 13:35:11','820a38a8-947b-4133-ad0b-ad06a28e5eab'),(7,1,'vCJcKyahXYmDpCnxiAg5dpZpAgiSS1TfTk0RxR4t1I_2nKCioDzGj5UNFfUhC7AiHzsdXJkBhwyCaH6wrxTV3BlMFh6kLSJCIwUf','2024-05-01 10:43:52','2024-05-01 11:53:26','2aca976b-6afe-4896-b3eb-907f02a839a9'),(8,1,'_pdcBDp_J-QDaZFHldU8wLyd_Um8JvdzD15VdtwJwuv5Zj38qPizxLdduJI3Ijde4wwQkd8Q3kSc_98r3LuI2V6XRm2dbXK4WXk5','2024-05-01 17:20:28','2024-05-01 17:24:54','ab37ef14-d0ae-4145-bdef-6fbf13b8f66c'),(9,1,'N_Nu-QOM2gGESa0FIlytTe7fHObXloGvV6s5B5A1tnZIwpFmkLTQ8JuJD140alyzfSdyO6Hg1V1Ca4aHgD4jApGmLsS45TKLs9A_','2024-05-06 11:38:30','2024-05-06 12:29:43','c576ec6f-36d2-493a-8195-aa708823dd53');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qjvhyynmwybqvawvudakfutymycdsohmptqx` (`userId`,`message`),
  CONSTRAINT `fk_zzclqxfowviqbhhosvtryztzuumgxyibldnw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qvqvvmfgcclplkmpdzenadvdqyptdcsraiqm` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'WebExpert-Craft','2024-04-22 12:05:28','2024-04-22 12:05:28',NULL,'69e8880e-4349-4104-8c10-fcf3553ad1ee');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dwyryhinygkshzodevamdfrjyvuriekeqtbm` (`dateDeleted`),
  KEY `idx_kedufzobgukuwrutbrtztrqtuzluzygbtxav` (`handle`),
  KEY `idx_wjsmpuhahjrwbdjzikpbjtexpdzczhtgjjop` (`sortOrder`),
  KEY `fk_klnsulguwumcbvpfbpkbapcmybqnlbtchovq` (`groupId`),
  CONSTRAINT `fk_klnsulguwumcbvpfbpkbapcmybqnlbtchovq` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'true','WebExpert-Craft','default','en-US',1,'$PRIMARY_SITE_URL',1,'2024-04-22 12:05:28','2024-04-22 12:05:28',NULL,'30150ce9-3e49-4ef5-a72c-62c684180f6e');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_iaubnsuaejpooxedghzgfeluqfzeyulmadrb` (`structureId`,`elementId`),
  KEY `idx_bqivzofnlqicpznmeshslqgfmdtzjvmsegci` (`root`),
  KEY `idx_bjycsnhaqzqasgqdqkvmeggcqgqsbvoitfzn` (`lft`),
  KEY `idx_mshjsdyjllbhaupiquwobknmhjhjtyfbafui` (`rgt`),
  KEY `idx_uewrfkodrdfevoddeehnvxidyjgyqkkgoknw` (`level`),
  KEY `idx_sbygpeviureqdbpzuiiiepghlwuvgdchpkgz` (`elementId`),
  CONSTRAINT `fk_iemvlspnftihjbldtdcnxdcobrfnbplrozqf` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_safklbwirpydhbpcpejtyzzpjnjbupivleac` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
INSERT INTO `structures` VALUES (1,NULL,'2024-04-29 12:22:57','2024-04-29 12:22:57',NULL,'6778af77-7849-4581-8a63-10512a12c7ad'),(2,NULL,'2024-05-06 12:29:41','2024-05-06 12:29:41',NULL,'f6da26e7-8b39-4c79-ac5d-a5e37dc0ab20');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_unjnbyhdjbzdgqqfmqewlgumdmqjnjndhpey` (`key`,`language`),
  KEY `idx_rexymkkdnzkmwsdrzfzftamgucldbyclowsv` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uwsicvznsfzwvizqyeccaksnkscewmaimfgk` (`name`),
  KEY `idx_gmqlpydrdcfwgsfhsudgudcldgkuhgspujxa` (`handle`),
  KEY `idx_anrnpdigktzbktxorfnnibamqwlgqowrrqwu` (`dateDeleted`),
  KEY `fk_ckjgreoppwbbbdjvpjorhtmifatdhyicojig` (`fieldLayoutId`),
  CONSTRAINT `fk_ckjgreoppwbbbdjvpjorhtmifatdhyicojig` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_jkuhjkbsryjoffqbxmdmcwmlbvtddixhhqkm` (`groupId`),
  CONSTRAINT `fk_lvbcolqmiefjsstdmymfrtxqdkiesannoopa` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_thyqfghzvbcxvwdxpoctdzlgmaftjqufhvkk` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mtbihzdfkvmfduafiprzvzubnwiflapfenel` (`token`),
  KEY `idx_wweqwnkkdihrvarmesaxrrgfglmvsphcjyjw` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zhkhfeakeqimxhopgstrdjpmqelghshjduom` (`handle`),
  KEY `idx_aomlzbdmpwqqopddqlegzlpftfsnungpdcan` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tscklfdqguradzlyxqoanqmhesvowjuvwamj` (`groupId`,`userId`),
  KEY `idx_auiwsmdlailjdndrobebqflfcuxaptnryqye` (`userId`),
  CONSTRAINT `fk_ntsmhuvcggzajmxcyagrykrcpgfhsfariezu` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rdoraidktigviujiltcnaelzvxzlcfhyhqjs` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_daidzrafmuwiritgxztsqalmhjwzmistsjlh` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jybojlrzgmkefcqmehpcsyjjqvpknedrniyl` (`permissionId`,`groupId`),
  KEY `idx_dqwicaptzocnemketrastjqzvtljjrxmtghj` (`groupId`),
  CONSTRAINT `fk_vdcxtrebedilrzagxewbywxhwsvpzgbjfpdb` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xggrlglohuruhoqrdawlptazytdvzixzxwoc` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wbowwggvtgqtxjyugafkchuccgastqydlxme` (`permissionId`,`userId`),
  KEY `idx_ehywqvipfgaxkrhnwdbspwfwiqrmuwhoztcq` (`userId`),
  CONSTRAINT `fk_jgnmejvbsqbzrjodrgogbesjltkswhrwjmei` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kcjbgqxuvkvyvxydnevdcrogydrqobuexkkp` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_zmdqvxcycfgcqdkclgmgcjrrcxorrfffmyms` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"locale\": null, \"language\": \"en-US\", \"useShapes\": false, \"weekStartDay\": \"1\", \"underlineLinks\": false, \"disableAutofocus\": \"\", \"profileTemplates\": false, \"showFieldHandles\": true, \"showExceptionView\": false, \"alwaysShowFocusRings\": false, \"notificationDuration\": \"5000\", \"enableDebugToolbarForCp\": false, \"enableDebugToolbarForSite\": false}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_oyfwzndgdyjljfvxkwyoqenwruqqoryanuij` (`active`),
  KEY `idx_dgwrgeumbikjwxzcbplrwrdrbndhlwmzgrgg` (`locked`),
  KEY `idx_btmsxhwfygnkmxkdwvntmnizzjxlvohzilqb` (`pending`),
  KEY `idx_jmnhpjqguveixkqaeuyygdjhaotawhxzzqib` (`suspended`),
  KEY `idx_bqwyzuawwzdzcjhxlkcowrfzwchbonrrnjkb` (`verificationCode`),
  KEY `idx_qxrxcycynbxaobbacolgufotkclqgzbznvbp` (`email`),
  KEY `idx_uiydcwdvpjpfilutyhldjkeagmqozrongrxf` (`username`),
  KEY `fk_rrcpkbwwqticpxbbxdzveoegivsmnzyzcnnl` (`photoId`),
  CONSTRAINT `fk_qfufknlicntskecesthvtxbnvpzwvlvgyfbn` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rrcpkbwwqticpxbbxdzveoegivsmnzyzcnnl` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'janhuysmans',NULL,NULL,NULL,'12201074@student.pxl.be','$2y$13$ynrxTgPtq4xQU9QlaoD0r.U0PciFL8V1veJKcjL44H2YVGgmLJRvW','2024-05-06 11:38:30',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2024-04-22 12:05:29','2024-04-22 12:05:29','2024-05-06 11:38:30');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lxygeuwchuhpnipbkzqgzjjkwcujlgbmvdyb` (`name`,`parentId`,`volumeId`),
  KEY `idx_ijiihfxwoctqkzzrfbrsfsfwefjdflwpxdbb` (`parentId`),
  KEY `idx_rncfylshcwhanzfojfuopdotyoshhftwplde` (`volumeId`),
  CONSTRAINT `fk_eydjcktaoafkzwgujenyjsxwwrkknnlrtnwd` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xnxqjfvxhdjkydtkoialmqcgqsmsbkmajmjd` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Images',NULL,'2024-04-22 13:10:10','2024-04-29 13:09:31','a6d55780-35ff-4360-a9f0-55dc7a33dd16'),(2,NULL,NULL,'Temporary Uploads',NULL,'2024-04-22 13:23:58','2024-04-22 13:23:58','cf567628-7c97-4d6a-9959-57ba9eab9ddc'),(3,2,NULL,'user_1','user_1/','2024-04-22 13:23:58','2024-04-22 13:23:58','c978886c-dfb4-48aa-a5bf-0ff1da0b047a');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zijfesnednddnlhdxpbdqyhdurkgyeptbkog` (`name`),
  KEY `idx_tuccmiynicdodhhistgrjjjmlaijeiqaorvw` (`handle`),
  KEY `idx_rulcsskjgigmvoxkuqmufwqerkhgbbiqmlpe` (`fieldLayoutId`),
  KEY `idx_yhqzldeiezeyoxzkrzcdebejjwynaohpjclz` (`dateDeleted`),
  CONSTRAINT `fk_rptpwfqnfupdhloosnulqrfetkjvtbxsabfe` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
INSERT INTO `volumes` VALUES (1,3,'Images','images','images','','','','site',NULL,'none',NULL,1,'2024-04-22 13:10:10','2024-04-29 13:09:31',NULL,'f28c5aef-a3e8-41b3-8623-2ba3f42c7cb7');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_pdalcrovzcqeeejtuaqjqxlztgwcibznaegs` (`userId`),
  CONSTRAINT `fk_pdalcrovzcqeeejtuaqjqxlztgwcibznaegs` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_udrxombcrvnmhtnsorrmoifirangsfojrxna` (`userId`),
  CONSTRAINT `fk_zyfzhcyyhdixbxnuepjfpaxhknppophkales` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2024-04-22 12:05:30','2024-04-22 12:05:30','05a66f51-ad48-49e7-859c-8ece4522fd34'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-04-22 12:05:30','2024-04-22 12:05:30','35337bf0-d67e-4af2-a5e8-dba4bc9751c7'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-04-22 12:05:30','2024-04-22 12:05:30','42b38a65-ae3c-4085-91c5-ceb9925ababd'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}',1,'2024-04-22 12:05:30','2024-04-22 12:05:30','ed64b746-5a7a-4fb9-9d60-aa5b66cabeff');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-06 12:30:13
